<?php defined('BASEPATH') OR exit('No direct script access allowed');

class TapCluster_model extends CI_Model
{
    public function getAll()
    {   
        $query = $this->db->query("SELECT t_tap_cluster.*, t_customers.nm_depan, t_customers.nm_belakang, t_customers.phone FROM t_customers 
            , t_tap_cluster where t_customers.uid_card=t_tap_cluster.UID order by time_in");
        $data = [];
        foreach($query->result() as $d) {
            $data[] = $d;
        }  
        return $data;
    }

    public function getforDashboard()
    {   
        $query = $this->db->query("SELECT t_tap_cluster.*, t_customers.nm_depan, t_customers.nm_belakang, t_customers.phone FROM t_customers 
            , t_tap_cluster where t_customers.uid_card=t_tap_cluster.UID order by time_in desc limit 20");
        $data = [];
        foreach($query->result() as $d) {
            $data[] = $d;
        }  
        return $data;
    }

    public function getByUID($uid)
    {   
        $data = null;
        $query = $this->db->query("SELECT t_tap_cluster.*, t_customers.nm_depan, t_customers.nm_belakang, t_customers.phone FROM t_customers 
            , t_tap_cluster where t_customers.uid_card=t_tap_cluster.UID and UID='$uid' order by time_in");
        foreach($query->result() as $d) {
            $data[] = $d;
        }  
        return $data;
    }
    
    public function getLastByUID($uid)
    {
        $query = $this->db->query("SELECT t_tap_cluster.*, t_customers.nm_depan, t_customers.nm_belakang, t_customers.phone FROM t_customers 
            , t_tap_cluster where t_customers.uid_card=t_tap_cluster.UID and UID='$uid' order by index_tap desc limit 1");
        $data = null;
        foreach($query->result() as $d) {
            $data = $d;
        }  
        return $data;
    }

    public function save($uid,$status,$door_in)
    { 
        $date = date('Y-m-d H:i:s'); 
        $this->db->query(" insert into t_tap_cluster (
            `UID`,
            `status`,
            `door_in`,
            `time_in`
        ) values (
            '$uid',
            '$status',
            '$door_in',
            '$date'
        ) ");
    }

    public function update($index,$status,$door_out)
    {   
        $date = date('Y-m-d H:i:s'); 
        $this->db->query(" 
        update t_tap_cluster set status = '$status',
                                door_out = '$door_out',
                                time_out = '$date'
        where index_tap = '$index' 
        ");
    }
}