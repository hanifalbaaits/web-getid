<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Access_model extends CI_Model
{    
    public function getByRole($role)
    {
        // $query = $this->db->query("SELECT a.access_id, a.role_id, m.nama_menu, m.url_menu, m.grup_menu FROM `t_access` a
        // INNER JOIN t_menu m ON a.menu_id=m.id_menu where a.role_id='$role' and a.status=1");

        $query = $this->db->query("SELECT a.access_id, a.role_id, b.nama_menu, b.url_menu, b.grup_menu FROM t_access a, t_menu b 
        WHERE a.menu_id = b.id_menu and a.role_id='$role' and a.status=1");
        
        foreach($query->result() as $d) {
            $data[] = $d;
        }  
        return $data;
    }

    public function getAll(){
       // $query = $this->db->query("SELECT a.access_id, a.role_id, a.menu_id,a.status, m.nama_menu, r.nm_role FROM `t_access` a INNER JOIN t_menu m ON a.menu_id=m.id_menu INNER JOIN t_role r ON a.role_id=r.id_role ORDER BY a.role_id , a.menu_id");
        
        $query = $this->db->query("SELECT a.access_id, a.role_id, a.menu_id, a.status, b.nama_menu, c.nm_role FROM t_access a, t_menu b , t_role c
        WHERE a.menu_id = b.id_menu and a.role_id=c.id_role ORDER BY a.role_id , a.menu_id");
        
        foreach ($query->result() as $d) {
            $data[] = $d;
        }
        return $data;
    }

    public function getAllMenu(){
        $query = $this->db->query("SELECT * FROM t_menu");
        foreach ($query->result() as $d) {
            $data[] = $d;
        }
        return $data;
    }

    public function getMenuById($id){
        $query = $this->db->query("SELECT * FROM t_menu where id_menu='$id'");
        foreach ($query->result() as $d) {
            $data = $d;
        }
        return $data;
    }

    public function save($role_id,$menu_id)
    { 
        $this->db->query(" insert into t_access (
            `role_id`,
            `menu_id`,
            `status`
        ) values (
            '$role_id',
            '$menu_id',
            '1'
        ) ");
    }

    public function update($access_id,$status)
    {   
        $this->db->query("update t_access set status = '$status' where access_id='$access_id'");
    }
}