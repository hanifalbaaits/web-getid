<?php defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model
{
    public function verifyLoginPassword($username,$password) {
        $hash = hash('sha256', $password);
        $qry = $this->db->query("select * from t_user where username = '$username' and status='1'");

        if($qry->num_rows() > 0) {
            foreach($qry->result() as $d) :
                $data = $d;
            endforeach;

            if($hash == $data->password) {
                return 1;
            }
            else {
                return 2;
            }
        }
        else {
            return 3;
        }
    }

    public function getAll()
    {   
        //$query = $this->db->query(" select * from t_user ");
        $query = $this->db->query("SELECT u.id_user, u.id_role, u.username, u.login, u.status , u.created_date,
        u.update_date, r.nm_role FROM t_user u , t_role r where u.id_role=r.id_role");
        
        foreach($query->result() as $d) {
            $data[] = $d;
        }  
        return $data;
    }
    
    public function getByUsername($username)
    {
        $query = $this->db->query(" select * from t_user where username='$username'");
        foreach($query->result() as $d) {
            $data = $d;
        }  
        return $data;
    }

    public function save($username,$password,$role)
    {
        $date = date('Y-m-d H:i:s'); 
        $hash = hash('sha256', $password);
        $this->db->query(" insert into t_user (
            `id_role`,
            `username`,
            `password`,
            `login`,
            `status`,
            `created_date`
        ) values (
            '$role',
            '$username',
            '$hash',
            '0',
            '1',
            '$date'
        ) ");
    }

    public function update($username,$password,$role)
    {   
        $date = date('Y-m-d H:i:s');
        $hash = hash('sha256', $password);
        $this->db->query(" 
        update t_user set password = '$hash',
                        id_role = '$role',
                        update_date = '$date'
        where username = '$username' 
        ");
    }

    public function updatePassword($username,$password)
    {   
        $date = date('Y-m-d H:i:s');
        $hash = hash('sha256', $password);
        $this->db->query(" 
        update t_user set password = '$hash',
                        update_date = '$date'
        where username = '$username' 
        ");
    }

    public function delete($username)
    {
        $this->db->query(" delete from t_user where username='$username'");
    }

    public function cek_username($username) {
        $q = $this->db->query(" select * from t_user where username = '$username' ");
        if($q->num_rows() > 0) {
            return false;
        }
        else {
            return true;
        }
    }

    public function checkOld($username, $pass) {
        $hash = hash('sha256',$pass);
        $q = " select * from t_user where username = '$username' and password = '$hash' ";
        $qry = $this->db->query($q);
        if( $qry->num_rows() > 0 ) {
            return true; 
        }
        else {
            return false;
        }
    }

    public function login_out($username,$log)
    {   
        $date = date('Y-m-d H:i:s');
        $this->db->query(" 
        update t_user set login = '$log',
                        update_date = '$date'
        where username = '$username' 
        ");
    }

    public function status($username,$status)
    {
        $date = date('Y-m-d H:i:s');
        $this->db->query(" 
        update t_user set status = '$status',
                        update_date = '$date'
        where username = '$username' 
        ");
    }
}