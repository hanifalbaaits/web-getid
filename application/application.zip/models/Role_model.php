<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Role_model extends CI_Model
{
    public function getAll()
    {   
        $query = $this->db->query(" select * from t_role");
        foreach($query->result() as $d) {
            $data[] = $d;
        }  
        return $data;
    }
    
    public function getById($id)
    {
        $query = $this->db->query(" select * from t_role where id_role='$id'");
        foreach($query->result() as $d) {
            $data = $d;
        }  
        return $data;
    }

    public function save($nm_role)
    { 
        $date = date('Y-m-d H:i:s'); 
        $this->db->query(" insert into t_role (
            `nm_role`,
            `status`,
            `created_date`
        ) values (
            '$nm_role',
            '1',
            '$date'
        ) ");
    }

    public function update($id,$nm_role)
    {   
        $date = date('Y-m-d H:i:s'); 
        $this->db->query("update t_role set nm_role = '$nm_role',
                        update_date = '$date'
        where id_role = '$id' 
        ");
    }

    public function delete($id)
    {
        $this->db->query(" delete from t_role where id_role='$id'");
    }

    public function status($id_role,$status)
    {
        $date = date('Y-m-d H:i:s');
        $this->db->query(" 
        update t_role set status = '$status',
                        update_date = '$date'
        where id_role = '$id_role' 
        ");
    }
}