<?php defined('BASEPATH') OR exit('No direct script access allowed');

class TapInventory_model extends CI_Model
{
    public function getAll()
    {   
        $query = $this->db->query("SELECT t_tap_inventory.*, t_inventory.kd_barang, t_inventory.kd_jenis, t_inventory.kd_lokasi, t_inventory.nama, t_inventory.merk, t_inventory.tipe, t_inventory.unit, t_inventory.value FROM t_inventory 
            , t_tap_inventory where t_inventory.uid_card=t_tap_inventory.UID order by time_in");
        foreach($query->result() as $d) {
            $data[] = $d;
        }  
        return $data;
    }

    public function getforDashboard()
    {   
        $query = $this->db->query("SELECT t_tap_inventory.*, t_inventory.kd_barang, t_inventory.kd_jenis, t_inventory.kd_lokasi, t_inventory.nama, t_inventory.merk, t_inventory.tipe, t_inventory.unit, t_inventory.value FROM t_inventory 
            , t_tap_inventory where t_inventory.uid_card=t_tap_inventory.UID order by time_in desc limit 20");
        foreach($query->result() as $d) {
            $data[] = $d;
        }  
        return $data;
    }

    public function getByLocation($kd_lokasi)
    {   
        $query = $this->db->query("SELECT t_tap_inventory.*, t_inventory.kd_barang,t_inventory.kd_jenis, t_inventory.kd_lokasi, t_inventory.nama, t_inventory.merk, t_inventory.tipe, t_inventory.unit, t_inventory.value FROM t_inventory 
            , t_tap_inventory where t_inventory.uid_card=t_tap_inventory.UID and t_inventory.kd_lokasi='$kd_lokasi' order by time_in");
        foreach($query->result() as $d) {
            $data[] = $d;
        }  
        return $data;
    }

    public function getByJenis($kd_jenis)
    {   
        $query = $this->db->query("SELECT t_tap_inventory.*,t_inventory.kd_barang, t_inventory.kd_jenis, t_inventory.kd_lokasi, t_inventory.nama, t_inventory.merk, t_inventory.tipe, t_inventory.unit, t_inventory.value FROM t_inventory 
            , t_tap_inventory where t_inventory.uid_card=t_tap_inventory.UID and t_inventory.kd_jenis='$kd_jenis' order by time_in");
        foreach($query->result() as $d) {
            $data[] = $d;
        }  
        return $data;
    }

    public function save($uid,$status)
    { 
        $date = date('Y-m-d H:i:s'); 
        $this->db->query(" insert into t_tap_inventory (
            `UID`,
            `status`,
            `time_in`
        ) values (
            '$uid',
            '$status',
            '$date'
        ) ");
    }
}