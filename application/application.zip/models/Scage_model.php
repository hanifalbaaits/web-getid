<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Scage_model extends CI_Model
{
    public function getAll()
    {   
        $query = $this->db->query(" select * from t_sensor_cage");
        foreach($query->result() as $d) {
            $data[] = $d;
        }  
        return $data;
    }
    
    public function getById($id)
    {
        $query = $this->db->query(" select * from t_sensor_cage where id='$id'");
        foreach($query->result() as $d) {
            $data = $d;
        }  
        return $data;
    }

    public function save($alias,$nama,$jenis,$description)
    { 
        $this->db->query(" insert into t_sensor_cage (
            `alias`,
            `nama`,
            `jenis`,
            `description`
        ) values (
            '$alias',
            '$nama',
            '$jenis',
            '$description'
        ) ");
    }

    public function update($id,$alias,$nama,$jenis,$description)
    {    
        $this->db->query("update t_sensor_cage set alias = '$alias',
                        nama = '$nama',
                        jenis = '$jenis',
                        description = '$description'
        where id = '$id' 
        ");
    }

    public function delete($id)
    {
        $this->db->query(" delete from t_sensor_cage where id='$id'");
    }

    public function saveSchedule($note)
    { 
        $date = date('Y-m-d H:i:s');
        $this->db->query(" insert into t_schedule (
            `schedule_time`,
            `note`
        ) values (
            '$date',
            '$note'
        ) ");
    }

    public function getControl()
    {   
        $query = $this->db->query("select * from t_controling_status");
        foreach($query->result() as $d) {
            $data[] = $d;
        }  
        return $data;
    }

    public function updateControl($id,$status,$command)
    {    
        $this->db->query("update t_controling_status set status = '$status',
                        command = '$command'
        where id = '$id' 
        ");
    }
}