<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Hcolor_model extends CI_Model
{
    public function getAll()
    {   
        $query = $this->db->query("SELECT * from t_history_fcolor order by time_update");
        foreach($query->result() as $d) {
            $data[] = $d;
        }  
        return $data;
    }

    public function getforToday()
    {   
        $today = date('Y-m-d');
        $query = $this->db->query("SELECT * from t_history_fcolor where time_update > '$today' order by time_update");
        foreach($query->result() as $d) {
            $data[] = $d;
        }  
        return $data;
    }

    public function getforDashboard()
    {   
        $query = $this->db->query("SELECT * from t_history_fcolor order by time_update desc limit 10");
        foreach($query->result() as $d) {
            $data[] = $d;
        }  
        return $data;
    }

    public function save($size,$color)
    { 
        $date = date('Y-m-d H:i:s'); 
        $this->db->query(" insert into t_history_fcolor (
            `size_status`,
            `color_status`,
            `time_update`
        ) values (
            '$size',
            '$color',
            '$date'
        ) ");
    }
}