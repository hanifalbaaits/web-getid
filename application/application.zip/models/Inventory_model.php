<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Inventory_model extends CI_Model
{
    public function getAll()
    {   
        $query = $this->db->query(" select * from t_inventory");
        foreach($query->result() as $d) {
            $data[] = $d;
        }  
        return $data;
    }

    public function getById($id)
    {
        $query = $this->db->query(" select * from t_inventory where kd_barang='$id'");
        $data = null;
        foreach($query->result() as $d) {
            $data = $d;
        }  
        return $data;
    }

    public function getByUID($uid)
    {
        $query = $this->db->query(" select * from t_inventory where uid_card='$uid'");
        $data = null;
        foreach($query->result() as $d) {
            $data = $d;
        }  
        return $data;
    }

    public function save($uid_card,$kd_jenis,$kd_lokasi,$nama,$merk,$tipe,$unit,$value)
    { 
        $this->db->query(" insert into t_inventory (
            `uid_card`,
            `kd_jenis`,
            `kd_lokasi`,
            `nama`,
            `merk`,
            `tipe`,
            `unit`,
            `value`
        ) values (
            '$uid_card',
            '$kd_jenis',
            '$kd_lokasi',
            '$nama',
            '$merk',
            '$tipe',
            '$unit',
            '$value'
        ) ");
    }

    public function update($kd_barang,$uid_card,$kd_jenis,$kd_lokasi,$nama,$merk,$tipe,$unit,$value)
    {   
        $this->db->query(" 
        update t_inventory set uid_card = '$uid_card',
                        kd_jenis = '$kd_jenis',
                        kd_lokasi = '$kd_lokasi',
                        nama = '$nama',
                        merk = '$merk' ,
                        tipe = '$tipe',
                        unit = '$unit',
                        value = '$value'
        where kd_barang = '$kd_barang' 
        ");
    }

    public function delete($kd_barang)
    {
        $this->db->query(" delete from t_inventory where kd_barang='$kd_barang'");
    }
}