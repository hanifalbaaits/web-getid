<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Hplant_model extends CI_Model
{
    public function getAll()
    {   
        $query = $this->db->query("SELECT t_history_plant.*, t_sensor_plant.alias, t_sensor_plant.nama, t_sensor_plant.jenis,t_sensor_plant.description FROM t_sensor_plant 
            , t_history_plant where t_sensor_plant.id=t_history_plant.id_sensor order by time_update");
        foreach($query->result() as $d) {
            $data[] = $d;
        }  
        return $data;
    }

    public function getforDashboard()
    {   
        $query = $this->db->query("SELECT t_history_plant.*, t_sensor_plant.alias, t_sensor_plant.nama, t_sensor_plant.jenis, t_sensor_plant.description FROM t_sensor_plant 
            , t_history_plant where t_sensor_plant.id=t_history_plant.id_sensor order by time_update desc limit 10");
        foreach($query->result() as $d) {
            $data[] = $d;
        }  
        return $data;
    }

    public function getById($id)
    {   
        $query = $this->db->query("SELECT t_history_plant.*, t_sensor_plant.alias, t_sensor_plant.nama , t_sensor_plant.jenis FROM t_sensor_plant 
            , t_history_plant where t_sensor_plant.id=t_history_plant.id_sensor and id_sensor='$id' order by time_update");
        foreach($query->result() as $d) {
            $data[] = $d;
        }  
        return $data;
    }
    
    public function getLastById($id)
    {
        $query = $this->db->query("SELECT t_history_plant.*, t_sensor_plant.alias, t_sensor_plant.nama, t_sensor_plant.jenis FROM t_sensor_plant 
            , t_history_plant where t_sensor_plant.id=t_history_plant.id_sensor and id_sensor='$id' order by time_update desc limit 1");
        $data=null;
        foreach($query->result() as $d) {
            $data = $d;
        }  
        return $data;
    }

    public function save($id,$value)
    { 
        $date = date('Y-m-d H:i:s'); 
        $this->db->query(" insert into t_history_plant (
            `id_sensor`,
            `value`,
            `time_update`
        ) values (
            '$id',
            '$value',
            '$date'
        ) ");
    }
}