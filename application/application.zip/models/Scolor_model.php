<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Scolor_model extends CI_Model
{
    public function getAll()
    {   
        $query = $this->db->query(" select * from t_filter_color");
        foreach($query->result() as $d) {
            $data[] = $d;
        }  
        return $data;
    }
    
    public function getById($id)
    {
        $query = $this->db->query(" select * from t_filter_color where id='$id'");
        foreach($query->result() as $d) {
            $data = $d;
        }  
        return $data;
    }

    public function getByAlias($alias)
    {
        $query = $this->db->query(" select * from t_filter_color where alias='$alias'");
        foreach($query->result() as $d) {
            $data = $d;
        }  
        return $data;
    }

    public function save($alias,$nama,$jenis,$description)
    { 
        $this->db->query(" insert into t_filter_color (
            `alias`,
            `nama`,
            `jenis`,
            `description`
        ) values (
            '$alias',
            '$nama',
            '$jenis',
            '$description'
        ) ");
    }

    public function update($id,$alias,$nama,$jenis,$description)
    {    
        $this->db->query("update t_filter_color set alias = '$alias',
                        nama = '$nama',
                        jenis = '$jenis',
                        description = '$description'
        where id = '$id' 
        ");
    }

    public function delete($id)
    {
        $this->db->query(" delete from t_filter_color where id='$id'");
    }
}