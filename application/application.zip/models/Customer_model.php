<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Customer_model extends CI_Model
{
    public function getAll()
    {   
        $query = $this->db->query(" select * from t_customers");
        foreach($query->result() as $d) {
            $data[] = $d;
        }  
        return $data;
    }

    public function getByRole($id_role)
    {   
        $query = $this->db->query("SELECT t_customers.*, t_user.id_role FROM t_customers , t_user 
        where t_customers.username=t_user.username and id_role='$id_role'");
        foreach($query->result() as $d) {
            $data[] = $d;
        }  
        return $data;
    }
    
    public function getByUsername($username)
    {
        $query = $this->db->query(" select * from t_customers where username='$username'");
        foreach($query->result() as $d) {
            $data = $d;
        }  
        return $data;
    }

    public function getByUID($uid)
    {
        $query = $this->db->query(" select * from t_customers where uid_card='$uid'");
        $data = null;
        foreach($query->result() as $d) {
            $data = $d;
        }  
        return $data;
    }

    public function save($username)
    { 
        $this->db->query(" insert into t_customers (
            `username`,
            `url_profile`
        ) values (
            '$username',
            '/default_profile.jpg'
        ) ");
    }

    public function update($username,$nm_depan,$nm_belakang,$email,$phone,$alamat,$jk,$pekerjaan,$no_ktp,$url,$uid)
    {   
        $this->db->query(" 
        update t_customers set nm_depan = '$nm_depan',
                        nm_belakang = '$nm_belakang',
                        email = '$email',
                        phone = '$phone',
                        alamat = '$alamat' ,
                        j_kelamin = '$jk',
                        pekerjaan = '$pekerjaan',
                        no_ktp = '$no_ktp',
                        url_profile = '$url',
                        uid_card = '$uid'
        where username = '$username' 
        ");
    }

    public function delete($username)
    {
        $this->db->query(" delete from t_customers where username='$username'");
    }
}