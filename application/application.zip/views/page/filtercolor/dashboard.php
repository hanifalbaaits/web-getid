<!-- page content -->
<div class="right_col" role="main">
  <!-- top tiles -->
  <div class="row">
    <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
      <div class="tile-stats">
        <div class="icon"><i class="fa fa-shopping-cart red"></i>
        </div>
        <div class="count red"><?php echo $m_kecil; ?></div>

        <h3>Merah Kecil</h3>
        <p>Total Hari ini</p>
      </div>
    </div>
    <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
      <div class="tile-stats">
        <div class="icon"><i class="fa fa-shopping-cart red"></i>
        </div>
        <div class="count red"><?php echo $m_besar; ?></div>

        <h3>Merah Besar</h3>
        <p>Total Hari ini</p>
      </div>
    </div>
    <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
      <div class="tile-stats">
        <div class="icon"><i class="fa fa-shopping-cart green"></i>
        </div>
        <div class="count green"><?php echo $h_kecil; ?></div>

        <h3>Hijau Kecil</h3>
        <p>Total Hari ini</p>
      </div>
    </div>
    <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
      <div class="tile-stats">
        <div class="icon"><i class="fa fa-shopping-cart green"></i>
        </div>
        <div class="count green"><?php echo $h_besar; ?></div>
        <h3>Hijau Besar</h3>
        <p>Total Hari ini</p>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col-md-12 col-sm-6 col-xs-12">
      <div class="x_panel">
        <div class="x_title">
          <h2>Monitoring Boarding<small>table realtime</small></h2>
          <div class="clearfix"></div>
        </div>
        
        <div class="x_content">
          <table class="table">
            <thead>
              <tr>
              <th>#</th>
              <th>Size Status</th>
              <th>Color Status</th>
              <th>Size Name</th>
              <th>Color Name</th>
              <th>Time Update</th>
              </tr>
            </thead>
            <tbody>
            <?php foreach ($history as $key => $his): ?>
                <tr>
                  <th scope="row"><?php echo ++$key; ?></td>
                  <th><?php echo $his->size_status; ?></td>
                  <th><?php echo $his->color_status; ?></td>
                  <td><?php echo $his->nm_size; ?></td>
                  <td><?php if($his->color_status == "CR000") {
                      echo '<span class="label label-danger">RED</span>'; 
                      } else {
                        echo '<span class="label label-success">GREEN</span>'; 
                        }?></td>
                  <td><?php echo $his->time_update; ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  <!-- tutup row -->
  </div> 

</div>
<!-- /page content -->

        
