<!-- page content -->
<div class="right_col" role="main">
  <!-- top tiles -->

  <div class="row tile_count">
    <div class="row">
    <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
        <div class="tile-stats">
          <div class="icon"><i class="fa fa-tachometer green"></i>
          </div>
         <?php 
            if($suhu->value<=28 && $suhu->value>=16){ //16 - 28 normal
              echo '<div class="count green">';
            } else if ($suhu->value<16 && $suhu->value>9) { //15-10 warning
              echo '<div class="count">';
            } else {
              echo '<div class="count red">'; //selain itu | <9 && >28
            }
          echo $suhu->value; ?></div>
          <h3>Temperature</h3>
          <p><?php 
               if($suhu->value<=28 && $suhu->value>=16){ //16 - 28 normal
                echo '<span class="label label-success">Normal</span>';
              } else if ($suhu->value<16 && $suhu->value>9) { //15-10 warning
                echo '<span class="label label-warning">Warning</span>';
              } else {
                echo '<span class="label label-danger">Danger</span>'; //selain itu | <9 && >28
              }
              ?>  
            Time Update : <?php echo $suhu->time_update; ?></p>
        </div>
      </div>
      
      <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
        <div class="tile-stats">
          <div class="icon"><i class="fa fa-tachometer green"></i>
          </div>
         <?php 
            if($kelembaban->value<=28 && $kelembaban->value>=16){ //16 - 28 normal
              echo '<div class="count green">';
            } else if ($kelembaban->value<16 && $kelembaban->value>9) { //15-10 warning
              echo '<div class="count">';
            } else {
              echo '<div class="count red">'; //selain itu | <9 && >28
            }
          echo $kelembaban->value; ?></div>
          <h3>Humidity</h3>
          <p><?php 
                  if($kelembaban->value<=28 && $kelembaban->value>=16){ //16 - 28 normal
                    echo '<span class="label label-success">Normal</span>';
                  } else if ($kelembaban->value<16 && $kelembaban->value>9) { //15-10 warning
                    echo '<span class="label label-warning">Warning</span>';
                  } else {
                    echo '<span class="label label-danger">Danger</span>'; //selain itu | <9 && >28
                  }
              ?>  
            Time Update : <?php echo $kelembaban->time_update ?></p>
        </div>
      </div>
      <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
        <div class="tile-stats">
          <div class="icon"><i class="fa fa-tachometer green"></i>
          </div>
         <?php 
              if($ldr->value<=28 && $ldr->value>=16){ //16 - 28 normal
                echo '<div class="count green">';
              } else if ($ldr->value<16 && $ldr->value>9) { //15-10 warning
                echo '<div class="count">';
              } else {
                echo '<div class="count red">'; //selain itu | <9 && >28
              }
          echo $ldr->value; ?></div>
          <h3>Light Sensor</h3>
          <p><?php 
                if($ldr->value<=28 && $ldr->value>=16){ //16 - 28 normal
                  echo '<span class="label label-success">Normal</span>';
                } else if ($ldr->value<16 && $ldr->value>9) { //15-10 warning
                  echo '<span class="label label-warning">Warning</span>';
                } else {
                  echo '<span class="label label-danger">Danger</span>'; //selain itu | <9 && >28
                }
              ?>  
            Time Update : <?php echo $kelembaban->time_update ?></p>
        </div>
      </div>
 
    </div>
  </div>


  <div class="row">
    <div class="col-md-6 col-sm-6 col-xs-12">
    <div class="x_panel">
      <div class="x_title">
        <h2>Plant 1</h2>
        <ul class="nav navbar-right panel_toolbox">
          <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
          </li>
          <li><a class="close-link"><i class="fa fa-close"></i></a>
          </li>
        </ul>
        <div class="clearfix"></div>
      </div>
      <div class="x_content">
        <div style="text-align: center; margin-bottom: 17px">
          <ul class="verticle_bars list-inline">
            <li>
              <div class="progress vertical progress_wide bottom">
                <div class="progress-bar progress-bar-info" role="progressbar" data-transitiongoal="<?php echo $suhu->value; ?>"></div>
              </div>
            </li>
            <li>
              <div class="progress vertical progress_wide bottom">
                <div class="progress-bar progress-bar-success" role="progressbar" data-transitiongoal="<?php echo $kelembaban->value; ?>"></div>
              </div>
            </li>
          </ul>
        </div>
        <div class="divider"></div>

        <ul class="legend list-unstyled">
          <li>
            <p>
              <span class="icon"><i class="fa fa-square blue"></i></span> <span class="name">Suhu</span>
            </p>
          </li>
          <li>
            <p>
              <span class="icon"><i class="fa fa-square green"></i></span> <span class="name">Kelembaban</span>
            </p>
          </li>
        </ul>

      </div>
    </div>
    </div>

    <div class="col-md-6 col-sm-6 col-xs-12">
      <div class="x_panel">
        <div class="x_title">
          <h2>History Sensor<small>table realtime</small></h2>
          <div class="clearfix"></div>
        </div>
        
        <div class="x_content">
          <table class="table">
            <thead>
              <tr>
                <th>#</th>
                <th>Sensor</th>
                <th>Name</th>
                <th>Last Update</th>
                <th>Description</th>
              </tr>
            </thead>
            <tbody>
            <?php $i = 1; foreach ($history as $his): ?>
              <tr>
                <th scope="row"><?php echo $i++; ?></th>
                <td><?php echo $his->alias;?></td>
                <td><?php echo $his->nama;?></td>
                <td><?php echo $his->time_update;?></td>
                <td><?php echo $his->description;?></td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    
  </div>

</div>


<!-- <script type="text/javascript">
  setTimeout(function(){
    location = '<?php echo site_url(); ?>/home/plantiot';
  },3000)
</script> -->

        
