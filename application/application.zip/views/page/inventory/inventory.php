<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>List Inventory</h3>
      </div>
      <div class="title_right">
     </div>
    </div>
    
    <div class="clearfix"></div>

    <div class="row">
      <div class="col-md-12">
        <div class="x_panel">
          <div class="x_title">
          <button type="button" class="btn btn-primary btn-xs" data-toggle="modal" data-target=".create-inventory" href="#">Add Inventory</button>
            <ul class="nav navbar-right panel_toolbox">
            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
              <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                <ul class="dropdown-menu" role="menu">
                  <li><a href="#">Filter Table</a></li>
                </ul>
              </li>
            </li>
            </ul>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">

            <p>Table for management inventory</p>

            <!-- start project list -->
            <table class="table table-striped projects">
              <thead>
                <tr>
                  <th style="width: 1%">#</th>
                  <th style="width: 20%">Name</th>
                  <th>UID</th>
                  <th>Category</th>
                  <th>Location</th>
                  <th>Type</th>
                  <th>Unit</th>
                  <th>Value</th>
                  <th style="width: 20%">#Edit</th>
                </tr>
              </thead>
              <tbody>
              <?php foreach ($inventory as $key => $inven): ?>
                <tr>
                  <td><?php echo ++$key; ?></td>
                  <td>
                    <a><?php echo $inven->nama?></a>
                    <br />
                    <small><?php echo $inven->merk;?></small>
                  </td>
                  <td><?php echo $inven->uid_card;?></td>
                  <td>
                    <a><?php if($inven->kd_jenis=="KD001"){echo 'Food';}
                          else if ($inven->kd_jenis=="KD002"){echo "Electronic";} else {echo "";}?></a>
                    <br />
                    <small><?php echo $inven->kd_jenis;?></small>
                  </td>
                  <td>
                    <a><?php if($inven->kd_lokasi=="LT001"){echo 'Floor 1';}
                          else if ($inven->kd_lokasi=="LT002"){echo "Floor 2";} else {echo "";}?></a>
                    <br />
                    <small><?php echo $inven->kd_lokasi;?></small>
                  </td>
                  <td><?php echo $inven->tipe; ?></td>
                  <td><?php echo $inven->unit; ?></td>
                  <td><?php echo $inven->value; ?></td>
                  <td>
                    <a href="#" onClick="return open_selected_inventory('<?php echo $inven->kd_barang; ?>')" class="btn btn-primary btn-xs" data-toggle="modal" data-target=".view-inventory"><i class="fa fa-folder" ></i> View </a>
                    <?php if($this->session->userdata('role') == '1' || $this->session->userdata('role') == '2') { ?>
                    <a href="#" onClick="return open_selected_inventory('<?php echo $inven->kd_barang; ?>')" class="btn btn-info btn-xs" data-toggle="modal" data-target=".edit-inventory"><i class="fa fa-pencil"></i> Edit </a>
                    <?php } ?>
                  </td>
                </tr>
                <?php endforeach; ?>
                 
              </tbody>
            </table>
            <!-- end project list -->

          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="modal fade create-inventory" tabindex="-1" role="dialog" aria-hidden="true">
<div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
        </button>
        <h4 class="modal-title" id="myModalLabel">Add Inventory</h4>
      </div>
      <div class="modal-body">
      <form data-parsley-validate class="form-horizontal form-label-left" method="post" enctype="multipart/form-data" action="<?php echo site_url(). "/inventory/addInventory" ?>">
      <div class="form-group">
        <label class="control-label col-md-3 col-sm-3 col-xs-12">Nama Barang</label>
        <div class="col-md-9 col-sm-9 col-xs-12">
          <input type="text" name="nama" id="nama" class="form-control" placeholder="Nama Barang" required >
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-3 col-sm-3 col-xs-12">Merk Barang</label>
        <div class="col-md-9 col-sm-9 col-xs-12">
          <input type="text" name="merk" id="merk" class="form-control" placeholder="Merk" required >
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-3 col-sm-3 col-xs-12">Kategori</label>
        <div class="col-md-9 col-sm-9 col-xs-12">
          <select name="jenis" id="jenis" class="form-control" required>
            <option value="KD001">Food</option>
            <option value="KD002">Electronic</option>
          </select>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-3 col-sm-3 col-xs-12">Lokasi</label>
        <div class="col-md-9 col-sm-9 col-xs-12">
          <select name="lokasi" id="lokasi" class="form-control" required >
            <option value="LT001">Lantai 1</option>
            <option value="LT002">Lantai 2</option>
          </select>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-3 col-sm-3 col-xs-12">Tipe</label>
        <div class="col-md-9 col-sm-9 col-xs-12">
          <input type="text" name="tipe" id="tipe" class="form-control" placeholder="null" >
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-3 col-sm-3 col-xs-12">Unit</label>
        <div class="col-md-3 col-sm-3 col-xs-12">
          <input type="text" name="unit" id="unit" class="form-control" placeholder="Satuan" required>
        </div>
        <label class="control-label col-md-1 col-sm-3 col-xs-12">Value</label>
        <div class="col-md-3 col-sm-3 col-xs-12">
          <input type="number" name="value" id="value" class="form-control" placeholder="Jumlah" required >
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-3 col-sm-3 col-xs-12">UID</label>
        <div class="col-md-3 col-sm-3 col-xs-12">
          <input type="text" name="uid" id="uid" class="form-control" placeholder="UID" required >
        </div>
      </div>
        
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      <button type="submit" class="btn btn-primary">Save changes</button>
    </div>
    </form>
  </div>
  </div>
</div>

<div class="modal fade edit-inventory" tabindex="-1" role="dialog" aria-hidden="true">
<div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
        </button>
        <h4 class="modal-title" id="myModalLabel">Edit Inventory</h4>
        <h6 class="modal-title" id="edit-kode"></h4>
      </div>
      <div class="modal-body">
      <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" method="post" enctype="multipart/form-data" action="<?php echo site_url(). "/inventory/editInventory" ?>">
      <div class="form-group">
        <label class="control-label col-md-3 col-sm-3 col-xs-12">Nama Barang</label>
        <div class="col-md-9 col-sm-9 col-xs-12">
          <input type="text" name="edit-kd" id="edit-kd" hidden readOnly>
          <input type="text" name="edit-nama" id="edit-nama" class="form-control" placeholder="Nama Barang" required >
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-3 col-sm-3 col-xs-12">Merk Barang</label>
        <div class="col-md-9 col-sm-9 col-xs-12">
          <input type="text" name="edit-merk" id="edit-merk" class="form-control" placeholder="Merk" required >
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-3 col-sm-3 col-xs-12">Kategori</label>
        <div class="col-md-9 col-sm-9 col-xs-12">
          <select name="edit-jenis" id="edit-jenis" class="form-control" required >
            <option value="KD001">Food</option>
            <option value="KD002">Electronic</option>
          </select>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-3 col-sm-3 col-xs-12">Lokasi</label>
        <div class="col-md-9 col-sm-9 col-xs-12">
          <select name="edit-lokasi" id="edit-lokasi" class="form-control" required>
            <option value="LT001">Lantai 1</option>
            <option value="LT002">Lantai 2</option>
          </select>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-3 col-sm-3 col-xs-12">Tipe</label>
        <div class="col-md-9 col-sm-9 col-xs-12">
          <input type="text" name="edit-tipe" id="edit-tipe" class="form-control" placeholder="null" >
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-3 col-sm-3 col-xs-12">Unit</label>
        <div class="col-md-3 col-sm-3 col-xs-12">
          <input type="text" name="edit-unit" id="edit-unit" class="form-control" placeholder="Satuan" required>
        </div>
        <label class="control-label col-md-1 col-sm-3 col-xs-12">Value</label>
        <div class="col-md-3 col-sm-3 col-xs-12">
          <input type="number" name="edit-value" id="edit-value" class="form-control" placeholder="Jumlah" required>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-3 col-sm-3 col-xs-12">UID</label>
        <div class="col-md-3 col-sm-3 col-xs-12">
          <input type="text" name="edit-uid" id="edit-uid" class="form-control" placeholder="UID" required>
        </div>
      </div>
        
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      <button type="submit" class="btn btn-primary">Save changes</button>
    </div>
    </form>
  </div>
  </div>
</div>

<div class="modal fade view-inventory" tabindex="-1" role="dialog" aria-hidden="true">
<div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
        </button>
        <h4 class="modal-title" id="myModalLabel">Data Inventory</h4>
        <h6 class="modal-title" id="view-kd"></h4>
      </div>
      <div class="modal-body">
      <form class="form-horizontal form-label-left">

      <div class="form-group">
        <label class="control-label col-md-3 col-sm-3 col-xs-12">Nama Barang</label>
        <div class="col-md-9 col-sm-9 col-xs-12">
          <input type="text" name="view-nama" id="view-nama" class="form-control" placeholder="Nama Barang" readOnly>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-3 col-sm-3 col-xs-12">Merk Barang</label>
        <div class="col-md-9 col-sm-9 col-xs-12">
          <input type="text" name="view-merk" id="view-merk" class="form-control" placeholder="Merk" readOnly>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-3 col-sm-3 col-xs-12">Kategori</label>
        <div class="col-md-9 col-sm-9 col-xs-12">
          <select name="view-jenis" id="view-jenis" class="form-control" readOnly>
            <option value="KD001">Food</option>
            <option value="KD002">Electronic</option>
          </select>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-3 col-sm-3 col-xs-12">Lokasi</label>
        <div class="col-md-9 col-sm-9 col-xs-12">
          <select name="view-lokasi" id="view-lokasi" class="form-control" readOnly>
            <option value="LT001">Lantai 1</option>
            <option value="LT002">Lantai 2</option>
          </select>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-3 col-sm-3 col-xs-12">Tipe</label>
        <div class="col-md-9 col-sm-9 col-xs-12">
          <input type="text" name="view-tipe" id="view-tipe" class="form-control" placeholder="null" readOnly>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-3 col-sm-3 col-xs-12">Unit</label>
        <div class="col-md-3 col-sm-3 col-xs-12">
          <input type="text" name="view-unit" id="view-unit" class="form-control" placeholder="Satuan" readOnly>
        </div>
        <label class="control-label col-md-1 col-sm-3 col-xs-12">Value</label>
        <div class="col-md-3 col-sm-3 col-xs-12">
          <input type="number" name="view-value" id="view-value" class="form-control" placeholder="Jumlah" readOnly>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-3 col-sm-3 col-xs-12">UID</label>
        <div class="col-md-3 col-sm-3 col-xs-12">
          <input type="text" name="view-uid" id="view-uid" class="form-control" placeholder="UID" readOnly>
        </div>
      </div>

    </form>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    </div>
  </div>
  </div>
</div>

<script type="text/javascript"> 
    function open_selected_inventory(id) {
      html = $.ajax({
            data : { kd_barang : id },
            type:"POST",
            url: "<?php echo site_url('inventory/getInventory');?>",
            async: false
      }).responseText;
      $("#view-kd").text("Kode:" + html.split("|")[0]).show();
      document.getElementById("view-uid").value = html.split("|")[1];
      document.getElementById("view-jenis").value = html.split("|")[2];
      document.getElementById("view-lokasi").value = html.split("|")[3];
      document.getElementById("view-nama").value = html.split("|")[4];
      document.getElementById("view-merk").value = html.split("|")[5];
      document.getElementById("view-tipe").value = html.split("|")[6];
      document.getElementById("view-unit").value = html.split("|")[7];
      document.getElementById("view-value").value = html.split("|")[8];

      $("#edit-kode").text("Kode:" + html.split("|")[0]).show();
      document.getElementById("edit-kd").value = html.split("|")[0];
      document.getElementById("edit-uid").value = html.split("|")[1];
      document.getElementById("edit-jenis").value = html.split("|")[2];
      document.getElementById("edit-lokasi").value = html.split("|")[3];
      document.getElementById("edit-nama").value = html.split("|")[4];
      document.getElementById("edit-merk").value = html.split("|")[5];
      document.getElementById("edit-tipe").value = html.split("|")[6];
      document.getElementById("edit-unit").value = html.split("|")[7];
      document.getElementById("edit-value").value = html.split("|")[8];
    }

  function check() {
      alert("se");
    }
</script>