<div id="dashboard">
<!-- page content -->
<div class="right_col" role="main">
  <!-- top tiles -->
  <div class="row">
    <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
      <div class="tile-stats">
        <div class="icon"><i class="fa fa-bar-chart"></i>
        </div>
        <div class="count"><?php echo count($history); ?></div>

        <h3>Total Inventory</h3>
        <p>Update : <?php echo $time_update; ?></p>
      </div>
    </div>
    <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
      <div class="tile-stats">
        <div class="icon"><i class="fa fa-cutlery green"></i>
        </div>
        <div class="count"><?php echo $food; ?></div>

        <h3>Food</h3>
        <p>In Floor1</p>
      </div>
    </div>
    <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
      <div class="tile-stats">
        <div class="icon"><i class="fa fa-plug blue"></i>
        </div>
        <div class="count"><?php echo $electronic; ?></div>

        <h3>Electronic</h3>
        <p>In Floor2</p>
      </div>
    </div>
    <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
      <div class="tile-stats">
        <div class="icon"><i class="fa fa-tachometer"></i>
        </div>
        <div class="count"><?php echo $persenTotal; ?> %</div>
        <h3>Capacity Warehouse</h3>
        <p>Update : <?php echo $time_update; ?></p>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col-md-6 col-sm-6 col-xs-12">
      <div class="x_panel">
        <div class="x_title">
          <h2>Monitoring Inventory<small>table realtime</small></h2>
          <div class="clearfix"></div>
        </div>
        
        <div class="x_content">
          <table class="table">
            <thead>
              <tr>
                <th>#</th>
                <th>UID</th>
                <th>Location</th>
                <th>Category</th>
                <th>Name</th>
                <th>Time In</th>
              </tr>
            </thead>
            <tbody>
          
            <?php foreach ($history as $key => $his): ?>
              <tr>
                <th scope="row"><?php echo ++$key; ?></th>
                <td><?php echo $his->UID;?></td>
                <td><?php if($his->kd_lokasi == "LT001") 
                {echo "Floor 1"; } else if($his->kd_lokasi == "LT002") {echo "Floor 2"; } else { echo "";}  ?></td>
                <td><?php if($his->kd_jenis == "KD001") {echo '<span class="label label-success">Food</span>'; } 
                else if($his->kd_jenis == "KD002") {echo '<span class="label label-primary">Electronic</span>'; } 
                else { echo "";}  ?></td>                  
                <td><?php echo $his->nama; ?></td>
                <td><?php echo $his->time_in; ?></td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <div class="col-md-6 col-sm-6 col-xs-12">
    <div class="x_panel">
      <div class="x_title">
        <h2>Warehouse Stock</h2>
        <ul class="nav navbar-right panel_toolbox">
          <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
          </li>
          <li><a class="close-link"><i class="fa fa-close"></i></a>
          </li>
        </ul>
        <div class="clearfix"></div>
      </div>
      <div class="x_content">

        <div style="text-align: center; margin-bottom: 17px">
          <ul class="verticle_bars list-inline">
            <li>
              <div class="progress vertical progress_wide bottom">
                <div class="progress-bar progress-bar-success" role="progressbar" data-transitiongoal="<?php echo $persenFood; ?>"></div>
              </div>
            </li>
            <li>
              <div class="progress vertical progress_wide bottom">
                <div class="progress-bar progress-bar-info" role="progressbar" data-transitiongoal="<?php echo $persenElectronic; ?>"></div>
              </div>
            </li>
          </ul>
        </div>
        <div class="divider"></div>

        <ul class="legend list-unstyled">
          <li>
            <p>
              <span class="icon"><i class="fa fa-square green"></i></span> <span class="name">
                Floor 1 | Capacity : <?php echo $persenFood; ?> %</span>
            </p>
          </li>
          <li>
            <p>
              <span class="icon"><i class="fa fa-square blue"></i></span> <span class="name">
                Floor 2 | Capacity : <?php echo $persenElectronic; ?> %</span>
            </p>
          </li>
        </ul>

      </div>
    </div>
    </div>

  <!-- tutup row -->
  </div> 

<!-- /page content -->
</div>

<script type="text/javascript">
  setTimeout(function(){
    location = '<?php echo site_url(); ?>/home/inventory';
  },3000)
</script>
        
