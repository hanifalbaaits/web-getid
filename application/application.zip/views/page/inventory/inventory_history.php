<div class="right_col" role="main">
    <div class="">
    <div class="page-title">
        <div class="title_left">
        <!-- <h3>Users <small>Some examples to get you started</small></h3> -->
        </div>
    </div>

    <div class="clearfix"></div>

    <div class="row">


<div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
            <h2>List History <small>Insert card for management inventory</small></h2>
            <ul class="nav navbar-right panel_toolbox">
                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
            </ul>
            <div class="clearfix"></div>
            </div>
            <div class="x_content">
            <table id="datatable-buttons" class="table table-striped table-bordered">
                <thead>
                <tr>
                    <th>Index</th>
                    <th>UID</th>
                    <th>Location</th>
                    <th>Category</th>      
                    <th>Name</th>
                    <th>Merk</th>
                    <th>Type</th>
                    <th>Unit</th>
                    <th>Value</th>
                    <th>Status</th>
                    <th>Time In</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($history as $key => $his): ?>
                <tr>
                  <td><?php echo ++$key; ?></td>
                  <td><?php echo $his->UID;?></td>
                  <td><?php if($his->kd_lokasi == "LT001") {echo "Floor 1"; } else if($his->kd_lokasi == "LT002") {echo "Floor 2"; } else { echo "";}  ?></td>
                  <td><?php if($his->kd_jenis == "KD001") {echo "Food"; } else if($his->kd_jenis == "KD002") {echo "Electronic"; } else { echo "";}  ?></td>                  
                  <td><?php echo $his->nama; ?></td>
                  <td><?php echo $his->merk; ?></td>
                  <td><?php echo $his->tipe; ?></td>
                  <td><?php echo $his->unit; ?></td>
                  <td><?php echo $his->value; ?></td>
                  <td><?php if($his->status == 0) {echo "IN"; } else {echo "OUT"; }?></td>
                  <td><?php echo $his->time_in; ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
        </div>
        </div>
        </div>
    </div>
</div>
