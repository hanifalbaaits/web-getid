<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>List Role</h3>
      </div>
      <div class="title_right">
     </div>
    </div>
    
    <div class="clearfix"></div>

    <div class="row">
      <div class="col-md-12">
        <div class="x_panel">
          <div class="x_title">
          <button type="button" class="btn btn-primary btn-xs" data-toggle="modal" data-target=".create-role" href="#">Add Role</button>
            <ul class="nav navbar-right panel_toolbox">
            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
              <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                <ul class="dropdown-menu" role="menu">
                  <li><a href="#">Filter Table</a></li>
                </ul>
              </li>
            </li>
            </ul>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">

            <p>Table for management role</p>

            <!-- start project list -->
            <table class="table table-striped projects">
              <thead>
                <tr>
                  <th style="width: 1%">#</th>
                  <th style="width: 20%">Name Role</th>
                  <th>Last Updated</th>
                  <th>Status</th>
                  <th style="width: 20%">#Action</th>
                </tr>
              </thead>
              <tbody>
              <?php $i = 1; foreach ($roles as $role): ?>
                <tr>
                  <td><?php echo $i++; ?></td>
                  <td>
                    <a><?php echo $role->nm_role;?></a>
                    <br />
                    <small>Created <?php echo $role->created_date;?></small>
                  </td>
                  <td><?php echo $role->update_date;?></td>
                  <?php
                    echo "<td>";
                    if($role->status == "1") {
                      $status="Active"; ?>
                      <a type="button" href="<?php echo site_url("role/changeStatus/$role->id_role/0"); ?>" onclick='return act_confirm()' class="btn btn-success btn-xs"><?php echo $status; ?></a>
              <?php } 
                    else {
                      $status="Non Active"; ?>
                      <a type="button" href="<?php echo site_url("role/changeStatus/$role->id_role/1"); ?>" onclick='return act_confirm()' class="btn btn-danger btn-xs"><?php echo $status; ?></a>
              <?php }
                    echo "</td>";
                  ?>
                  <td>
                    <a href="#" onClick="return open_selected_role('<?php echo $role->id_role; ?>')" class="btn btn-primary btn-xs" data-toggle="modal" data-target=".view-role"><i class="fa fa-folder" ></i> View </a>
                    <?php if($this->session->userdata('role') == '1') { ?>
                    <a href="#" onClick="return open_selected_role('<?php echo $role->id_role; ?>')" class="btn btn-info btn-xs" data-toggle="modal" data-target=".edit-role"><i class="fa fa-pencil"></i> Edit </a>
                    <a href="<?php echo site_url("role/deleteRole/$role->id_role"); ?>" onclick='return del_confirm()' class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Delete </a>
                    <?php } ?>
                  </td>
                </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
            <!-- end project list -->

          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="modal fade create-role" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
        </button>
        <h4 class="modal-title" id="myModalLabel">Create Role</h4>
      </div>
      <div class="modal-body">
      <form data-parsley-validate class="form-horizontal form-label-left" method="post" enctype="multipart/form-data" action="<?php echo site_url(). "/role/addRole" ?>">
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Role name <span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" name="nm_role" id="nm_role" required="required" class="form-control col-md-7 col-xs-12">
          </div>
        </div>
        
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      <button type="submit" class="btn btn-primary">Save changes</button>
    </div>
    </form>
  </div>
  </div>
</div>

<div class="modal fade view-role" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
        </button>
        <h4 class="modal-title" id="myModalLabel">View Role</h4>
        <span id="span-status" class="label label-success"></span>
        <span id="span-status-danger" class="label label-danger"></span>
      </div>
      <div class="modal-body">
      <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">ID Role <span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="view-id_role" required="required" class="form-control col-md-7 col-xs-12" readOnly>
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Role name <span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="view-nm_role" required="required" class="form-control col-md-7 col-xs-12" readOnly>
          </div>
        </div>
        </form>
    </div>
    <div class="modal-footer">
       <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    </div>
  </div>
  </div>
</div>

<div class="modal fade edit-role" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
        </button>
        <h4 class="modal-title" id="myModalLabel">Edit Role</h4>
      </div>
      <div class="modal-body">
      <form data-parsley-validate class="form-horizontal form-label-left" method="post" enctype="multipart/form-data" action="<?php echo site_url(). "/role/editRole" ?>">
      <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="edit-id_role">ID Role <span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" name="edit-id_role" id="edit-id_role" required="required" class="form-control col-md-7 col-xs-12">
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="edit-nm_role">Role name <span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" name="edit-nm_role" id="edit-nm_role" required="required" class="form-control col-md-7 col-xs-12">
          </div>
        </div>
     
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      <button type="submit" class="btn btn-primary">Save changes</button>
    </div>
    </form>
  </div>
  </div>
</div>

<script type="text/javascript"> 
    function open_selected_role(id) {
      html = $.ajax({
            data : { id_role : id },
            type:"POST",
            url: "<?php echo site_url('role/getRole');?>",
            async: false
      }).responseText;
      let status = html.split("|")[2];
      
      document.getElementById("view-id_role").value = html.split("|")[0];
      document.getElementById("view-nm_role").value = html.split("|")[1];
      document.getElementById("edit-id_role").value = html.split("|")[0];
      document.getElementById("edit-nm_role").value = html.split("|")[1];

      if(status == "1"){
        $("#span-status").text("Active").show();
        $("#span-status-danger").text("Non Active").hide();
       } else 
       {
        $("#span-status").text("Active").hide();
        $("#span-status-danger").text("Non Active").show();
      }
    }
</script>