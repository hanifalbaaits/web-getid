<div id="dashboard">
    
</div>

<script type="text/javascript">
     function autoreload(){
    $('#dashboard').load("<?php echo site_url(); ?>/home/dashboard");
  }

  setInterval(() => {
    autoreload();
  }, 1000);
</script>

