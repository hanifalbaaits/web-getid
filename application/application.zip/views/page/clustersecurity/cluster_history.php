<div class="right_col" role="main">
    <div class="">
    <div class="page-title">
        <div class="title_left">
        <!-- <h3>List History <small> Tap card for cluster security</small></h3> -->
        </div>
    </div>

    <div class="clearfix"></div>

    <div class="row">


<div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
            <h2>List History <small>Tap card for cluster security</small></h2>
            <ul class="nav navbar-right panel_toolbox">
                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
            </ul>
            <div class="clearfix"></div>
            </div>
            <div class="x_content">
            <table id="datatable-buttons" class="table table-striped table-bordered">
                <thead>
                <tr>
                    <th>Index</th>
                    <th>UID</th>
                    <th>Name</th>
                    <th>Phone</th>
                    <th>Status</th>
                    <th>Door In</th>
                    <th>Time In</th>
                    <th>Door Out</th>
                    <th>Time Out</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($history as $key => $his): ?>
                <tr>
                  <td><?php echo ++$key; ?></td>
                  <td><?php echo $his->UID;?></td>
                  <td><?php echo $his->nm_depan . " " . $his->nm_belakang; ?></td>
                  <td><?php echo $his->phone;?></td>
                  <td><?php if($his->status == 0) {echo "IN"; } else {echo "OUT"; }?></td>
                  <td><?php if($his->door_in == null) {echo ""; } else if($his->door_in == 0) {echo "North Door"; } else { echo "South Door";}  ?></td>
                  <td><?php echo $his->time_in; ?></td>
                  <td><?php if($his->door_out == null) {echo ""; } else if($his->door_out == 0) {echo "North Door"; } else {echo "South Door";} ?></td>
                  <td><?php echo $his->time_out; ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
        </div>
        </div>
        </div>
    </div>
</div>
