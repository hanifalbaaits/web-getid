<div id="dashboard">
<!-- page content -->
<div class="right_col" role="main">
  <!-- top tiles -->   

  <div class="row">
    <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
      <div class="tile-stats">
        <div class="icon"><i class="fa fa-bar-chart-o"></i>
        </div>
        <div class="count"><?php echo $all; ?></div>

        <h3>Total Customer</h3>
        <p>Update : <?php echo $last->time_in; ?></p>
      </div>
    </div>
    <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
      <div class="tile-stats">
      <div class="icon"><i class="fa fa-arrow-circle-o-down green"></i>
        </div>
        <div class="count green"><?php echo $in; ?></div>

        <h3>Customer IN</h3>
        <p>Update : <?php echo $last->time_in; ?></p>
      </div>
    </div>
    <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
      <div class="tile-stats">
      <div class="icon"><i class="fa fa-arrow-circle-o-up red"></i>
        </div>
        <div class="count red"><?php echo $out; ?></div>

        <h3>Customer OUT</h3>
        <p>Update : <?php echo $last->time_in; ?></p>
      </div>
    </div>
    <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
      <div class="tile-stats">
      <div class="icon"><i class="fa fa-user blue"></i>
        </div>
        <div class="count"><?php echo $last->nm_depan; ?></div>
        <h3>Last Tap</h3>
        <p>Card UID: <?php echo $last->UID; ?></p>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col-md-6 col-sm-6 col-xs-12">
      <div class="x_panel">
        <div class="x_title">
          <h2>Monitoring Boarding<small>table realtime</small></h2>
          <div class="clearfix"></div>
        </div>
        
        <div class="x_content">
          <table class="table">
            <thead>
              <tr>
                <th>#</th>
                <!-- <th>UID</th> -->
                <th>Name</th>
                <th>Phone</th>
                <th>Status</th>
                <th>Room</th>
                <th>Time In</th>
                <th>Time Out</th>
              </tr>
            </thead>
            <tbody>
            <?php foreach ($history as $key => $his): ?>
                <tr>
                  <th scope="row"><?php echo ++$key; ?></td>
                  <!-- <td><?php echo $his->UID;?></td> -->
                  <td><?php echo $his->nm_depan . " " . $his->nm_belakang; ?></td>
                  <td><?php echo $his->phone;?></td>
                  <td><?php if($his->status == 0) {
                      echo '<span class="label label-success">IN</span>'; 
                      } else {
                        echo '<span class="label label-danger">OUT</span>'; 
                        }?></td>
                  <td><?php if($his->door == null) {echo ""; } else if($his->door == 0) {echo "Melati"; } else { echo "Mawar";}  ?></td>
                  <td><?php echo $his->time_in; ?></td>
                  <td><?php echo $his->time_out; ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <div class="col-md-3 col-xs-12 widget widget_tally_box">
      <div class="x_panel">
        <div class="x_content">

          <h3 class="name">Melati Room</h3>

          <div class="flex">
            <ul class="list-inline count2">
            <h4 class="name">
                <?php 
                if($melati->status==0){
                  echo "Room Filled";
                } else {
                  echo "Room Empty";
                }
                ?>
            </h4>
            <h5 class="name"><?php echo $melati->nm_depan . " " . $melati->nm_belakang; ?></h5>
            </ul>
          </div>
          <p>
            <?php 
                if($melati->status==0){
                  echo " Entrance in, ".$melati->time_in;
                } else {
                  echo "Out in, ".$melati->time_out;
                }
            ?>
          </p>
        </div>
      </div>
    </div>

    <div class="col-md-3 col-xs-12 widget widget_tally_box">
      <div class="x_panel">
        <div class="x_content">

          <h3 class="name">Mawar Room</h3>

          <div class="flex">
            <ul class="list-inline count2">
            <h4 class="name">
            <?php 
                if($mawar->status==0){
                  echo "Room Filled";
                } else {
                  echo "Room Empty";
                }
                ?>
            </h4>
            <h5 class="name"><?php echo $mawar->nm_depan . " " . $mawar->nm_belakang; ?></h5>
            </ul>
          </div>
          <p>
            <?php 
                if($mawar->status==0){
                  echo " Entrance in, ".$melati->time_in;
                } else {
                  echo "Out in, ".$melati->time_out;
                }
            ?>
          </p>
        </div>
      </div>
    </div>
  

  <!-- tutup row -->
  </div> 

</div>
<!-- /page content -->

<script type="text/javascript">
  setTimeout(function(){
    location = '<?php echo site_url(); ?>/home/boardinghouse';
  },3000)
</script>

        
