<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>List Customers</h3>
      </div>
      <div class="title_right">
     </div>
    </div>
    
    <div class="clearfix"></div>

    <div class="row">
      <div class="col-md-12">
        <div class="x_panel">
          <div class="x_title">
            <ul class="nav navbar-right panel_toolbox">
            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
              <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                <ul class="dropdown-menu" role="menu">
                  <li><a href="#">Filter Table</a></li>
                </ul>
              </li>
            </li>
            </ul>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">

            <p>Table for management customers</p>

            <!-- start project list -->
            <table class="table table-striped projects">
              <thead>
                <tr>
                  <th style="width: 1%">#</th>
                  <th style="width: 20%">Username</th>
                  <th>Full Name</th>
                  <th>Phone</th>
                  <th>Address</th>
                  <th>UID Card</th>
                  <th style="width: 20%">#Edit</th>
                </tr>
              </thead>
              <tbody>
              <?php foreach ($customers as $key => $cust): ?>
                <tr>
                  <td><?php echo ++$key; ?></td>
                  <td>
                    <a><?php echo $cust->username?></a>
                    <br />
                    <small><?php if($cust->j_kelamin==0){echo ' Female';}
                          else {echo " Male";}?>
                    </small>
                  </td>
                  <td><?php echo $cust->nm_depan." ".$cust->nm_belakang;?></td>
                  <td><?php echo $cust->phone; ?></td>
                  <td><?php echo $cust->alamat; ?></td>
                  <td><?php echo $cust->uid_card; ?></td>
                  <td>
                    <a href="#" onClick="return open_selected_customer('<?php echo $cust->username; ?>')" class="btn btn-primary btn-xs" data-toggle="modal" data-target=".view-customer"><i class="fa fa-folder" ></i> View </a>
                    <?php if($this->session->userdata('role') == '1' || $this->session->userdata('role') != '7' ) { ?>
                    <a href="#" onClick="return open_selected_customer('<?php echo $cust->username; ?>')" class="btn btn-info btn-xs" data-toggle="modal" data-target=".edit-customer"><i class="fa fa-pencil"></i> Edit </a>
                    <?php } ?>
                  </td>
                </tr>
                <?php endforeach; ?>
                 
              </tbody>
            </table>
            <!-- end project list -->

          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="modal fade edit-customer" tabindex="-1" role="dialog" aria-hidden="true">
<div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
        </button>
        <h4 class="modal-title" id="myModalLabel">Customers</h4>
        <h6 class="modal-title" id="header-username"></h4>
      </div>
      <div class="modal-body">
      <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" method="post" enctype="multipart/form-data" action="<?php echo site_url(). "/customers/editCustomer" ?>">
        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
        <!-- HIDEEEN -->
          <input type="text" id="edit-username" name="edit-username" hidden="true"> 
          <input type="text" id="edit-url" name="edit-url" hidden="true"> 
        <!-- HIDEEN -->
          <input type="text" class="form-control has-feedback-left" id="edit-nm_depan" name="edit-nm_depan" placeholder="First Name" required>
          <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
        </div>

        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
          <input type="text" class="form-control" id="edit-nm_belakang" name="edit-nm_belakang" placeholder="Last Name" required>
          <span class="fa fa-user form-control-feedback right" aria-hidden="true"></span>
        </div>

        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
          <input type="email" class="form-control has-feedback-left" id="edit-email" name="edit-email" placeholder="Email" required>
          <span class="fa fa-envelope form-control-feedback left" aria-hidden="true"></span>
        </div>

        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
          <input type="number" class="form-control" id="edit-phone" name="edit-phone" placeholder="Phone" required>
          <span class="fa fa-phone form-control-feedback right" aria-hidden="true"></span>
        </div>

        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
          <input type="text" class="form-control has-feedback-left" id="edit-no_ktp" name="edit-no_ktp" placeholder="NO KTP">
          <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
        </div>

        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
          <input type="text" class="form-control" id="edit-uid_card" name="edit-uid_card" placeholder="Card UID" required>
          <span class="fa fa-key form-control-feedback right" aria-hidden="true"></span>
        </div>

        <!-- <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12">Gender</label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <div id="view-j_kelamin" class="btn-group" data-toggle="buttons">
              <label class="btn btn-default" data-toggle-class="btn-primary" data-toggle-passive-class="btn-default">
                <input type="radio" name="jek" checked>Male
              </label>
              <label class="btn btn-default" data-toggle-class="btn-primary" data-toggle-passive-class="btn-default">
                <input type="radio" name="jek">Female
              </label>
            </div>
          </div>
        </div> -->

        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12">Select</label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <select id="edit-j_kelamin" name="edit-j_kelamin" class="form-control" required>
                  <option value="1">Male</option>  
                  <option value="0">Female</option>              
            </select>
          </div>
        </div>   


        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12">Address <span class="required">*</span>
          </label>
          <div class="col-md-9 col-sm-9 col-xs-12">
            <input id="edit-alamat" name="edit-alamat" class="date-picker form-control col-md-7 col-xs-12" type="text">
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12">Job <span class="required">*</span>
          </label>
          <div class="col-md-9 col-sm-9 col-xs-12">
            <input id="edit-pekerjaan" name="edit-pekerjaan" class="date-picker form-control col-md-7 col-xs-12" type="text">
          </div>
        </div>
        
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      <button type="submit" class="btn btn-primary">Save changes</button>
    </div>
    </form>
  </div>
  </div>
</div>

<div class="modal fade view-customer" tabindex="-1" role="dialog" aria-hidden="true">
<div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
        </button>
        <h4 class="modal-title" id="myModalLabel">Customers</h4>
        <h6 class="modal-title" id="view-username"></h4>
      </div>
      <div class="modal-body">
      <form class="form-horizontal form-label-left input_mask">
        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
          <input type="text" class="form-control has-feedback-left" id="view-nm_depan" placeholder="First Name" readOnly>
          <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
        </div>

        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
          <input type="text" class="form-control" id="view-nm_belakang" placeholder="Last Name" readOnly>
          <span class="fa fa-user form-control-feedback right" aria-hidden="true"></span>
        </div>

        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
          <input type="text" class="form-control has-feedback-left" id="view-email" placeholder="Email" readOnly>
          <span class="fa fa-envelope form-control-feedback left" aria-hidden="true"></span>
        </div>

        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
          <input type="text" class="form-control" id="view-phone" placeholder="Phone" readOnly>
          <span class="fa fa-phone form-control-feedback right" aria-hidden="true"></span>
        </div>

        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
          <input type="text" class="form-control has-feedback-left" id="view-no_ktp" placeholder="NO KTP" readOnly>
          <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
        </div>

        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
          <input type="text" class="form-control" id="view-uid_card" placeholder="Card UID" readOnly>
          <span class="fa fa-key form-control-feedback right" aria-hidden="true"></span>
        </div>

        <!-- <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12">Gender</label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <div id="view-j_kelamin" class="btn-group" data-toggle="buttons">
              <label class="btn btn-default" data-toggle-class="btn-primary" data-toggle-passive-class="btn-default">
                <input type="radio" name="jek" checked>Male
              </label>
              <label class="btn btn-default" data-toggle-class="btn-primary" data-toggle-passive-class="btn-default">
                <input type="radio" name="jek">Female
              </label>
            </div>
          </div>
        </div> -->

        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12">Select</label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <select id="view-j_kelamin" name="view-j_kelamin" class="form-control" disabled>
                  <option value="1">Male</option>  
                  <option value="0">Female</option>              
            </select>
          </div>
        </div>   


        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12">Address <span class="required">*</span>
          </label>
          <div class="col-md-9 col-sm-9 col-xs-12">
            <input id="view-alamat" class="date-picker form-control col-md-7 col-xs-12" type="text" readOnly>
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12">Job <span class="required">*</span>
          </label>
          <div class="col-md-9 col-sm-9 col-xs-12">
            <input id="view-pekerjaan" class="date-picker form-control col-md-7 col-xs-12" type="text" readOnly>
          </div>
        </div>
        
      </form>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    </div>
  </div>
  </div>
</div>

<script type="text/javascript"> 
    function open_selected_customer(id) {
      html = $.ajax({
            data : { username : id },
            type:"POST",
            url: "<?php echo site_url('customers/getCustomer');?>",
            async: false
      }).responseText;
      $("#view-username").text(html.split("|")[0]).show();
      document.getElementById("view-nm_depan").value = html.split("|")[1];
      document.getElementById("view-nm_belakang").value = html.split("|")[2];
      document.getElementById("view-email").value = html.split("|")[3];
      document.getElementById("view-phone").value = html.split("|")[4];
      document.getElementById("view-alamat").value = html.split("|")[5];
      document.getElementById("view-j_kelamin").value = html.split("|")[6];
      document.getElementById("view-pekerjaan").value = html.split("|")[7];
      document.getElementById("view-no_ktp").value = html.split("|")[8];
      document.getElementById("view-uid_card").value = html.split("|")[9];

      $("#header-username").text(html.split("|")[0]).show();
      document.getElementById("edit-username").value = html.split("|")[0];
      document.getElementById("edit-nm_depan").value = html.split("|")[1];
      document.getElementById("edit-nm_belakang").value = html.split("|")[2];
      document.getElementById("edit-email").value = html.split("|")[3];
      document.getElementById("edit-phone").value = html.split("|")[4];
      document.getElementById("edit-alamat").value = html.split("|")[5];
      document.getElementById("edit-j_kelamin").value = html.split("|")[6];
      document.getElementById("edit-pekerjaan").value = html.split("|")[7];
      document.getElementById("edit-no_ktp").value = html.split("|")[8];
      document.getElementById("edit-uid_card").value = html.split("|")[9];
      document.getElementById("edit-url").value = html.split("|")[10];
    }

  function check() {
      alert("se");
    }
</script>