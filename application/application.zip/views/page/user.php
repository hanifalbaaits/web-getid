<?php 
?>
<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>List User</h3>
      </div>
      <div class="title_right">
     </div>
    </div>
    
    <div class="clearfix"></div>

    <div class="row">
      <div class="col-md-12">
        <div class="x_panel">
          <div class="x_title">
          <button type="button" class="btn btn-primary btn-xs" data-toggle="modal" data-target=".create-user" href="#">Add User</button>
            <ul class="nav navbar-right panel_toolbox">
            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
              <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                <ul class="dropdown-menu" role="menu">
                  <li><a href="#">Filter Table</a></li>
                </ul>
              </li>
            </li>
            </ul>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">

            <p>Table for management user</p>

            <!-- start project list -->
            <table class="table table-striped projects">
              <thead>
                <tr>
                  <th style="width: 1%">#</th>
                  <th style="width: 20%">Username</th>
                  <th>Role</th>
                  <th>Last Updated</th>
                  <th>Status</th>
                  <th style="width: 20%">#Action</th>
                </tr>
              </thead>
              <tbody>
                <?php $i = 1; foreach ($users as $user): ?>
                <tr>
                  <td><?php echo $i++; ?></td>
                  <td>
                    <a><?php echo $user->username;?></a>
                    <br />
                    <small>Created <?php echo $user->created_date;?></small>
                  </td>
                  <td><?php echo $user->nm_role;?></td>
                  <td><?php echo $user->update_date;?></td>
                  <?php
                    echo "<td>";
                    if($user->status == "1") {
                      $status="Active"; ?>
                      <a type="button" href="<?php echo site_url("user/changeStatus/$user->username/0"); ?>" onclick='return act_confirm()' class="btn btn-success btn-xs"><?php echo $status; ?></a>
              <?php } 
                    else {
                      $status="Banned"; ?>
                      <a type="button" href="<?php echo site_url("user/changeStatus/$user->username/1"); ?>" onclick='return act_confirm()' class="btn btn-danger btn-xs"><?php echo $status; ?></a>
              <?php }
                    echo "</td>";
                  ?>
                  <td>
                    <a href="#" onClick="return open_selected_user('<?php echo $user->username; ?>')" class="btn btn-primary btn-xs" data-toggle="modal" data-target=".view-user"><i class="fa fa-folder" ></i> View </a>
                    <?php if($this->session->userdata('role') == '1') { ?>
                    <a href="#" onClick="return open_selected_user('<?php echo $user->username; ?>')" class="btn btn-info btn-xs" data-toggle="modal" data-target=".edit-user"><i class="fa fa-pencil"></i> Edit </a>
                    <a href="<?php echo site_url("user/deleteUser/$user->username"); ?>" onclick='return del_confirm()' class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Delete </a>
                    <?php } ?>
                  </td>
                </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
            <!-- end project list -->

          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="modal fade create-user" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
        </button>
        <h4 class="modal-title" id="myModalLabel">Create User</h4>
      </div>
      <div class="modal-body">
      <form data-parsley-validate class="form-horizontal form-label-left" method="post" enctype="multipart/form-data" action="<?php echo site_url(). "/user/addUser" ?>">
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Username <span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="username" name="username" required="required" class="form-control col-md-7 col-xs-12">
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Password <span class="required">*</span>
          </label>
        <div class="col-md-6 col-sm-6 col-xs-12">
          <input type="password" id="password" name="password" required="required" class="form-control col-md-7 col-xs-12">
        </div>
        </div>
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Re-Password <span class="required">*</span>
          </label>
        <div class="col-md-6 col-sm-6 col-xs-12">
          <input type="password" id="retype" name="retype" required="required" class="form-control col-md-7 col-xs-12">
        </div>
        </div>
        <div class="form-group">
         
          <label class="control-label col-md-3 col-sm-3 col-xs-12">Select</label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <select id="role" name="role" class="form-control">
            <?php foreach ($roles as $key => $role): ?>
                <option value="<?php echo $role->id_role; ?>"><?php echo $role->nm_role; ?></option>
            <?php endforeach; ?>
            </select>
          </div>
        </div>
        
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      <button type="submit" class="btn btn-primary">Save changes</button>
    </div>
    </form>
  </div>
  </div>
</div>

<div class="modal fade edit-user" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
        </button>
        <h4 class="modal-title" id="myModalLabel">Edit User</h4>
      </div>
      <div class="modal-body">
      <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" method="post" enctype="multipart/form-data" action="<?php echo site_url(). "/user/editUser" ?>">
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Username <span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="edit-username" name="edit-username" readonly required="required" class="form-control col-md-7 col-xs-12">
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Password <span class="required">*</span>
          </label>
        <div class="col-md-6 col-sm-6 col-xs-12">
          <input type="password" id="password" name="password" required="required" class="form-control col-md-7 col-xs-12">
        </div>
        </div>
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Re-Password <span class="required">*</span>
          </label>
        <div class="col-md-6 col-sm-6 col-xs-12">
          <input type="password" id="retype" name="retype" required="required" class="form-control col-md-7 col-xs-12">
        </div>
        </div>
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12">Select</label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <select id="edit_selected-role" name="edit_selected-role" class="form-control">
            <?php foreach ($roles as $key => $role): ?>
                <option value="<?php echo $role->id_role; ?>"><?php echo $role->nm_role; ?></option>
            <?php endforeach; ?>
            </select>
          </div>
        </div>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      <button type="submit" class="btn btn-primary">Save changes</button>
    </div>
    </form>
  </div>
  </div>
</div>

<div class="modal fade view-user" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
        </button>
        <h4 class="modal-title" id="myModalLabel">View User</h4>
        <span id="span-status" class="label label-success"></span>
        <span id="span-status-danger" class="label label-danger"></span>
        <span id="span-login" class="label label-success"></span>
        <span id="span-login-danger" class="label label-danger"></span>
      </div>
      <div class="modal-body">
      <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Username
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="view-username" name="view-username" readonly="readonly" required="required" class="form-control col-md-7 col-xs-12">
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12">Select</label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <select id="view_selected-role" name="view_selected-role" class="form-control" disabled>
              <?php foreach ($roles as $key => $role): ?>
                  <option value="<?php echo $role->id_role; ?>"><?php echo $role->nm_role; ?></option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>           
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Last Updated
          </label>
        <div class="col-md-6 col-sm-6 col-xs-12">
          <input type="text" id="view-update_date" name="view-update_date" readonly="readonly" required="required" class="form-control col-md-7 col-xs-12">
        </div>
        </div>
        </form>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    </div>
  </div>
  </div>
</div>

<script type="text/javascript"> 
    function open_selected_user(id) {
      html = $.ajax({
            data : { username : id },
            type:"POST",
            url: "<?php echo site_url('user/getUser');?>",
            async: false
      }).responseText;
      let status = html.split("|")[4];
      let login = html.split("|")[3];

      document.getElementById("view-username").value = html.split("|")[2];
      document.getElementById("edit-username").value = html.split("|")[2];
      document.getElementById("view-update_date").value = html.split("|")[6];
      $("#view_selected-role").val(html.split("|")[1]).trigger('change');
      $("#edit_selected-role").val(html.split("|")[1]).trigger('change');
    
      if(status == "1"){
        $("#span-status").text("Active").show();
        $("#span-status-danger").text("Banned").hide();
       } else 
       {
        $("#span-status").text("Active").hide();
        $("#span-status-danger").text("Banned").show();
      }
    
      if(login == "1"){
        $("#span-login").text("Online").show();
        $("#span-login-danger").text("Offline").hide();
      } else {
        $("#span-login").text("Online").hide();
        $("#span-login-danger").text("Offline").show();
      }
    }
</script>