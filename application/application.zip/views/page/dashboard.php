<div id="dashboard">
<!-- page content -->
<div class="right_col" role="main">
  <!-- top tiles -->
  <div class="row tile_count">
    
    <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
      <span class="count_top"><i class="fa fa-user"></i> Total Users</span>
      <div class="count"><?php echo count($users);?></div>
      <span class="count_bottom"> All of Time</span>
    </div>
    <?php
        $online = []; $offline=[]; $active=[]; $banned=[];
        foreach ($users as $user) {
          if ($user->login=="1"){
            $online[] = $user;
          } else {
            $offline[] = $user;
          }
          if ($user->status=="1"){
            $active[] = $user;
          } else {
            $banned[] = $user;
          }
        }
      ?>
    <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
      <span class="count_top"><i class="fa fa-user"></i> Total Online User</span>
      <div class="count green"><?php echo count($online); ?></div>
      <span class="count_bottom"><i class="green"></i> All of Time</span>
    </div>
    <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
      <span class="count_top"><i class="fa fa-user"></i> Total Offline User</span>
      <div class="count red"><?php echo count($offline); ?></div>
      <span class="count_bottom"><i class="red"></i> All of Time</span>
    </div>
    <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
      <span class="count_top"><i class="fa fa-user"></i> Total Active User</span>
      <div class="count blue"><?php echo count($active); ?></div>
      <span class="count_bottom"><i class="blue"></i> All of Time</span>
    </div>
    <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
      <span class="count_top"><i class="fa fa-user"></i> Total Banned User</span>
      <div class="count red"><?php echo count($banned); ?></div>
      <span class="count_bottom"><i class="red"></i> All of Time</span>
    </div>
  </div>

  <div class="row">
    <div class="col-md-6 col-sm-6 col-xs-12">
      <div class="x_panel">
        <div class="x_title">
          <h2>Monitoring User<small>table user activity</small></h2>
          <div class="clearfix"></div>
        </div>
        
        <div class="x_content">
          <table class="table">
            <thead>
              <tr>
                <th>#</th>
                <th>Username</th>
                <th>Role</th>
                <th>Last Login</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
            <?php $i = 1; foreach ($users as $user): ?>
              <tr>
                <th scope="row"><?php echo $i++; ?></th>
                <td><?php echo $user->username;?></td>
                <td><?php echo $user->id_role;?></td>
                 <?php
                    if($user->login == "1") {
                    ?>
                    <td>NOW</td>
                    <td><span class="label label-success">Online</span></td>
              <?php } 
                    else {?>
                    <td><?php echo $user->update_date; ?></td>
                      <td><span class="label label-danger">Offline</span></td>
              <?php }
                  ?>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <div class="col-md-6 col-sm-6 col-xs-12">
      <div class="x_panel">
        <div class="x_title">
          <h2>Monitoring Service <small>table active feature</small></h2>
          <div class="clearfix"></div>
        </div>
        
        <div class="x_content">
          <table class="table">
            <thead>
              <tr>
                <th>#</th>
                <th>Service Name</th>
                <th>Note</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th scope="row">1</th>
                <td>Inventory</td>
                <td>Monitoring Inventory</td>
                <td><span class="label label-primary">Running</span></td>
              </tr>
              <tr>
                <th scope="row">2</th>
                <td>Cluster Security</td>
                <td>Monitoring Cluster Security</td>
                <td><span class="label label-primary">Running</span></td>
              </tr>
              <tr>
                <th scope="row">3</th>
                <td>Boarding House</td>
                <td>Monitoring Boarding House</td>
                <td><span class="label label-primary">Running</span></td>
              </tr>
              <tr>
                <th scope="row">4</th>
                <td>Plant Moisture</td>
                <td>Monitoring Plant</td>
                <td><span class="label label-primary">Running</span></td>
              </tr>
              <tr>
                <th scope="row">5</th>
                <td>Smart Cage</td>
                <td>Monitoring Smart Cage</td>
                <td><span class="label label-primary">Running</span></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

  <!-- tutup row -->
  </div> 

</div>
<!-- /page content -->
</div>

<script type="text/javascript">
  // setTimeout(function(){
  //   location = '<?php echo site_url(); ?>/home/dashboard';
  // },3000)

  //    function autoreload(){
  //   $('#dashboard').load("<?php echo site_url(); ?>/home/dashboard");
  // }

  // setInterval(() => {
  //   autoreload();
  // }, 1000);
</script>



        
