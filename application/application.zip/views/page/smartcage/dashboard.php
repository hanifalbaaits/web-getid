<!-- page content -->
<div class="right_col" role="main">
  <!-- top tiles -->
  <div class="row tile_count">
    <div class="row">
      <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
        <div class="tile-stats">
          <div class="icon"><i class="fa fa-line-chart"></i>
          </div>
          <div class="count"><?php echo $temp->value; ?> C</div>
          <h3>Temperatur</h3>
          <p>Update : <?php echo $temp->time_update; ?></p>
        </div>
      </div>
      
      <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
        <div class="tile-stats">
          <div class="icon"><i class="fa fa-tachometer green"></i>
          </div>
         <?php 
            if($persen>40){
              echo '<div class="count green">';
            } else {
              echo ' <div class="count red">';
            }
          echo number_format($persen,1); ?> %</div>
          <h3>Food Capacity</h3>
          <p><?php 
                if($persen>40){
                  echo '<span class="label label-success">Normal</span>';
                } else {
                  echo '<span class="label label-danger">Low</span>';
                }
              ?>  
            Value HCSR : <?php echo $hcsr->value ?> CM</p>
        </div>
      </div>
      <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
        <div class="tile-stats">
          <div class="icon"><i class="fa fa-home"></i>
          </div>
          <div class="count">LED</div>
          <h3><?php echo $led->command; ?></h3>
          <p>Update : <?php echo $hcsr->time_update; ?></p>
        </div>
      </div>
      <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
        <div class="tile-stats">
          <div class="icon"><i class="fa fa-cogs"></i>
          </div>
          <div class="count">Status</div>
          <h3>Servo & Motor</h3>
          <p>Servo : <?php echo $servo->command; ?> | Motor : <?php echo $motor->command; ?></p>
        </div>
      </div>
      
    </div>
  </div>
  
  <div class="row">
    <div class="x_panel">
      <div class="x_title">
        <h2>Live Streaming SmartCage <small>IP: 192.168.0.0</small></h2>
        <ul class="nav navbar-right panel_toolbox">
          <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
          </li>
          <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
            <ul class="dropdown-menu" role="menu">
              <li><a href="#">Settings 1</a>
              </li>
              <li><a href="#">Settings 2</a>
              </li>
            </ul>
          </li>
          <li><a class="close-link"><i class="fa fa-close"></i></a>
          </li>
        </ul>
        <div class="clearfix"></div>
      </div>
      <div class="x_content">
        <div class="col-md-7 col-sm-7 col-xs-12">
          <div class="product-image">
            <iframe width="500" height="315"
              src="https://www.youtube.com/embed/x8XoaD8j1So">
            </iframe>
          </div>
        </div>

        <div class="col-md-5 col-sm-5 col-xs-12" style="border:0px solid #e5e5e5;">

          <h3 class="prod_title">Monitoring and Controlling Smart Cage</h3>
          <p>Push Button you want, sloftly. See the monitoring indicator. Dont Forget to push button stop and restart after controlling</p>
          <br />

          <div class="">
            <h2>Control Button <small>Please select one</small></h2>
            <ul class="list-inline prod_size">
              <li>
                <a type="button" href="<?php echo site_url("smartcage/control/motor/1"); ?>" onclick='return act_confirm()' class="btn btn-default btn-xs"> <- Go Left</a>
              </li>
              <li>
                <a type="button" href="<?php echo site_url("smartcage/control/motor/0"); ?>" onclick='return act_confirm()' class="btn btn-default btn-xs">Stop</a>
              </li>
              <li>
                <a type="button" href="<?php echo site_url("smartcage/control/restart/1"); ?>" onclick='return act_confirm()' class="btn btn-default btn-xs">Restart</a>
              </li>
              <li>
                <a type="button" href="<?php echo site_url("smartcage/control/motor/2"); ?>" onclick='return act_confirm()' class="btn btn-default btn-xs">Go Right -></a>
              </li>
            </ul>
          </div>
          <br />

          <div class="">
          <?php if($servo->status==0){ ?>
            <a type="button" href="<?php echo site_url("smartcage/control/servo/1"); ?>" onclick='return act_confirm()' class="btn btn-default btn-lg">Open Feed</a>
          <?php } else { ?>
            <a type="button" href="<?php echo site_url("smartcage/control/servo/0"); ?>" onclick='return act_confirm()' class="btn btn-default btn-lg">Closed Feed</a>
          <?php }
            if($led->status==0){ ?>
            <a type="button" href="<?php echo site_url("smartcage/control/led/1"); ?>" onclick='return act_confirm()' class="btn btn-default btn-lg">Turn On LED</a> 
          <?php } else { ?>
            <a type="button" href="<?php echo site_url("smartcage/control/led/0"); ?>" onclick='return act_confirm()' class="btn btn-default btn-lg">Turn OFF LED</a> 
          <?php }?> 
          </div>
        </div>
      </div>
    </div>
  </div>
  
</div>
<!-- /page content -->

<script type="text/javascript">
  // setTimeout(function(){
  //   location = '<?php echo site_url(); ?>/home/smartcage';
  // },3000)
</script>

        
