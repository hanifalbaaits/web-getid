<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>List Data</h3>
      </div>
      <div class="title_right">
     </div>
    </div>
    
    <div class="clearfix"></div>

    <div class="row">
      <div class="col-md-12">
        <div class="x_panel">
          <div class="x_title">
          <button type="button" class="btn btn-primary btn-xs" data-toggle="modal" data-target=".create-scage" href="#">Add Data</button>
            <ul class="nav navbar-right panel_toolbox">
            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
              <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                <ul class="dropdown-menu" role="menu">
                  <li><a href="#">Filter Table</a></li>
                </ul>
              </li>
            </li>
            </ul>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">

            <p>Table for management data realtime</p>

            <!-- start project list -->
            <table class="table table-striped projects">
              <thead>
                <tr>
                  <th style="width: 1%">#</th>
                  <th>Alias</th>
                  <th>Name</th>
                  <th>Type</th>
                  <th style="width: 20%">Description</th>
                  <th style="width: 20%">#Action</th>
                </tr>
              </thead>
              <tbody>
              <?php $i = 1; foreach ($scage as $sc): ?>
                <tr>
                  <td><?php echo $i++; ?></td>
                  <td><?php echo $sc->alias;?></td>     
                  <td><?php echo $sc->nama;?></td>
                  <td><?php echo $sc->jenis;?></td>
                  <td><?php echo $sc->description;?></td>
                  <td>
                    <a href="#" onClick="return open_selected_scage('<?php echo $sc->id; ?>')" class="btn btn-primary btn-xs" data-toggle="modal" data-target=".view-scage"><i class="fa fa-folder" ></i> View </a>
                    <?php if($this->session->userdata('role') == '1') { ?>
                    <a href="#" onClick="return open_selected_scage('<?php echo $sc->id; ?>')" class="btn btn-info btn-xs" data-toggle="modal" data-target=".edit-scage"><i class="fa fa-pencil"></i> Edit </a>
                    <a href="<?php echo site_url("smartcage/deleteScage/$sc->id"); ?>" onclick='return del_confirm()' class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Delete </a>
                    <?php } ?>
                  </td>
                </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
            <!-- end project list -->

          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="modal fade create-scage" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
        </button>
        <h4 class="modal-title" id="myModalLabel">Create Data</h4>
      </div>
      <div class="modal-body">
      <form data-parsley-validate class="form-horizontal form-label-left" method="post" enctype="multipart/form-data" action="<?php echo site_url(). "/smartcage/addScage" ?>">
      <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Alias <span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="alias" name="alias" required="required" class="form-control col-md-7 col-xs-12" >
          </div>
        </div>

        <div class="form-group">    
          <label class="control-label col-md-3 col-sm-3 col-xs-12">Select</label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <select id="jenis" name="jenis" class="form-control">
                <option value="Sensor">Sensor</option>
                <option value="Object">Object</option>
            </select>
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Nama<span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="nama" name="nama" required="required" class="form-control col-md-7 col-xs-12" >
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Description<span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <textarea type="text" id="description" name="description" required="required" class="form-control col-md-7 col-xs-12" ></textarea>
          </div>
        </div>
        
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      <button type="submit" class="btn btn-primary">Save changes</button>
    </div>
    </form>
  </div>
  </div>
</div>

<div class="modal fade view-scage" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
        </button>
        <h4 class="modal-title" id="myModalLabel">View Data</h4>
      </div>
      <div class="modal-body">
      <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Alias <span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="view-alias" name="view-alias" required="required" class="form-control col-md-7 col-xs-12" readOnly>
          </div>
        </div>

        <div class="form-group">    
          <label class="control-label col-md-3 col-sm-3 col-xs-12">Select</label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <select id="view-jenis" name="view-jenis" class="form-control" readOnly>
                <option value="Sensor">Sensor</option>
                <option value="Object">Object</option>
            </select>
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Nama<span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="view-nama" name="view-nama" required="required" class="form-control col-md-7 col-xs-12" readOnly>
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Description<span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <textarea type="text" id="view-description" name="view-description" required="required" class="form-control col-md-7 col-xs-12" readOnly></textarea>
          </div>
        </div>
        </form>
    </div>
    <div class="modal-footer">
       <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    </div>
  </div>
  </div>
</div>

<div class="modal fade edit-scage" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
        </button>
        <h4 class="modal-title" id="myModalLabel">Edit Data</h4>
      </div>
      <div class="modal-body">
      <form data-parsley-validate class="form-horizontal form-label-left" method="post" enctype="multipart/form-data" action="<?php echo site_url(). "/smartcage/editScage" ?>">
      <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Alias <span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="edit-id" name="edit-id" required="required" hidden>
            <input type="text" id="edit-alias" name="edit-alias" required="required" class="form-control col-md-7 col-xs-12" >
          </div>
        </div>

        <div class="form-group">    
          <label class="control-label col-md-3 col-sm-3 col-xs-12">Select</label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <select id="edit-jenis" name="edit-jenis" class="form-control">
                <option value="Sensor">Sensor</option>
                <option value="Object">Object</option>
            </select>
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Nama<span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="edit-nama" name="edit-nama" required="required" class="form-control col-md-7 col-xs-12" >
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Description<span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <textarea type="text" id="edit-description" name="edit-description" required="required" class="form-control col-md-7 col-xs-12" ></textarea>
          </div>
        </div>
     
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      <button type="submit" class="btn btn-primary">Save changes</button>
    </div>
    </form>
  </div>
  </div>
</div>

<script type="text/javascript"> 
    function open_selected_scage(id) {
      html = $.ajax({
            data : { id : id },
            type:"POST",
            url: "<?php echo site_url('smartcage/getScage');?>",
            async: false
      }).responseText;
      
      document.getElementById("view-alias").value = html.split("|")[1];
      document.getElementById("view-nama").value = html.split("|")[2];
      document.getElementById("view-jenis").value = html.split("|")[3];
      document.getElementById("view-description").value = html.split("|")[4];

      document.getElementById("edit-id").value = html.split("|")[0];
      document.getElementById("edit-alias").value = html.split("|")[1];
      document.getElementById("edit-nama").value = html.split("|")[2];
      document.getElementById("edit-jenis").value = html.split("|")[3];
      document.getElementById("edit-description").value = html.split("|")[4];
    }
</script>