<div class="right_col" role="main">
    <div class="">
    <div class="page-title">
        <div class="title_left">
        <!-- <h3>Users <small>Some examples to get you started</small></h3> -->
        </div>
    </div>

    <div class="clearfix"></div>

    <div class="row">


<div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
            <h2>List History <small>History Monitoring smartcage</small></h2>
            <ul class="nav navbar-right panel_toolbox">
                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
            </ul>
            <div class="clearfix"></div>
            </div>
            <div class="x_content">
            <table id="datatable-buttons" class="table table-striped table-bordered">
                <thead>
                <tr>
                    <th>Index</th>
                    <th>Alias</th>
                    <th>Name</th>
                    <th>Type</th>      
                    <th>Value</th>
                    <th>Time</th>
                    <th>Note</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($hcage as $key => $his): ?>
                <tr>
                  <td><?php echo ++$key; ?></td>
                  <td><?php echo $his->alias;?></td>
                  <td><?php echo $his->nama?></td>
                  <td><?php echo $his->jenis; ?></td>
                  <td><?php echo $his->value; ?></td>
                  <td><?php echo $his->time_update; ?></td>
                  <td>Normal</td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
        </div>
        </div>
        </div>
    </div>
</div>
