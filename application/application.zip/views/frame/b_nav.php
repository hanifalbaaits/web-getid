<div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
              <a href="index.html" class="site_title">
              <!-- <i class="fa fa-paw"></i>  -->
              <span>Goentur Development</span></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <div class="profile clearfix">
              <div class="profile_pic">
                <img src="<?php echo base_url(). "images/profile".$this->session->userdata('url') ?>" alt="..." class="img-circle profile_img">
              </div>
              <div class="profile_info">
                <span>Welcome,</span>
                <h2><?php echo $this->session->userdata('nama') ?></h2>
              </div>
            </div>
            <!-- /menu profile quick info -->
            <br />

            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>General</h3>
                <ul class="nav side-menu">
                <?php if($this->session->userdata('role') ==1) {?>
                <li><a href="<?php echo site_url(). "/home/dashboard" ?>"><i class="fa fa-laptop">   
                    </i>Dashboard<span class="label label-success pull-right">Coming Soon</span></a>
                </li>
                <?php }
                $grup1 = [];
                $grup2 = [];
                $grup3 = [];
                $grup4 = [];
                foreach ($menus as $menu) {
                  if ($menu->grup_menu=="1"){
                    $grup1[] = $menu;
                  } else if ($menu->grup_menu=="2") {
                    $grup2[] = $menu;
                  } else if ($menu->grup_menu=="3"){
                    $grup3[] = $menu;
                  } else {
                    $grup4[] = $menu;
                  }
                }
                ?>
                
                <?php if($grup1 != null){?>
                <li><a><i class="fa fa-home"></i> Home <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <?php foreach ($grup1 as $key => $menu): 
                        if($key == 0 && $this->session->userdata("role") != 1){ //GANTIDISINI UMAR/REKY?>
                          <li><a href="<?php echo site_url(). $menu->url_menu; ?>"><?php echo $menu->nama_menu; ?></a></li>
                      <?php break;} else { ?>
                          <li><a href="<?php echo site_url(). $menu->url_menu; ?>"><?php echo $menu->nama_menu; ?></a></li>
                     <?php }endforeach; ?>
                    </ul>
                  </li>
                  <?php 
                  }   
                  ?>

                  <?php if(count($grup2)>0){?>
                  <li><a><i class="fa fa-users"></i> Master <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                    <?php foreach ($grup2 as $menu):?>
                          <li><a href="<?php echo site_url(). $menu->url_menu; ?>"><?php echo $menu->nama_menu; ?></a></li>
                    <?php endforeach; ?>
                    </ul>
                  </li>
                  <?php 
                  }   
                  ?>

                  <?php if(count($grup3)>0 && $this->session->userdata("role")!=1){?>
                  <li><a><i class="fa fa-edit"></i><?php if($this->session->userdata("role")==8){
                      echo "History Data"; } else {echo $grup1[0]->nama_menu;}?>
                      <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                    <?php foreach ($grup3 as $key => $menu): 
                        if($key == 0 && $this->session->userdata("role")==8){ //GANTIDISINI UMAR/REKY?>
                          <li><a href="<?php echo site_url(). $menu->url_menu; ?>"><?php echo $menu->nama_menu; ?></a></li>
                      <?php } if (($key==0 || $key==1) && $this->session->userdata("role")!=8) {?>
                        <li><a href="<?php echo site_url(). $menu->url_menu; ?>"><?php echo $menu->nama_menu; ?></a></li>
                    <?php  } 
                    endforeach; ?>
                    </ul>
                  </li>
                  <?php 
                  } else {
                    foreach ($grup1 as $key => $menu) { ?>
                      <li><a><i class="fa fa-edit"></i><?php echo $menu->nama_menu; ?><span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                        <?php for ($i=0; $i < 2; $i++) { $data = $grup3[($key*2)+$i]?>
                          <li><a href="<?php echo site_url(). $data->url_menu; ?>"><?php echo $data->nama_menu; ?></a></li>
                        <?php  
                        } ?>
                        </ul>
                      </li>        
                  <?php   
                    }   
                  ?>
                  <?php 
                  } 
                  ?>
                </ul>
              </div>
              <div class="menu_section">
                <h3>About</h3>
                <ul class="nav side-menu">
                  <li><a href="<?php echo site_url(). "/about/bogangdevelop" ?>"><i class="fa fa-info"></i>Bogang Development</a></li>
                  <?php if(count($grup4)>0){?>
                  <li><a><i class="fa fa-info"></i>Feature Menu<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                    <?php foreach ($grup4 as $menu): ?>
                        <li><a href="<?php echo site_url(). $menu->url_menu; ?>"><?php echo $menu->nama_menu; ?></a></li>
                    <?php endforeach; ?>
                    </ul>
                  </li>
                  <?php 
                  }   
                  ?>
                </ul>
              </div>

            </div>
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" data-placement="top" title="Settings">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Lock">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Logout" href="login.html">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav">
          <div class="nav_menu">
            <nav>
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>

              <ul class="nav navbar-nav navbar-right">
                <li class="">
                  <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    <img src="<?php echo base_url(). "images/profile".$this->session->userdata('url') ?>" alt=""><?php echo $this->session->userdata('nama') ?>
                    <span class=" fa fa-angle-down"></span>
                  </a>
                  <ul class="dropdown-menu dropdown-usermenu pull-right">
                    <!-- <li><a href="<?php echo site_url(). "/profile" ?>"> Profile</a></li> -->
                    <li><a href="#" data-toggle="modal" data-target=".change-password">Change Password</a></li>
                    <li><a href="javascript:;">Help</a></li>
                    <li><a href="<?php echo site_url(). "/login/user_logout" ?>"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
                  </ul>
                </li>
              </ul>
            </nav>
          </div>
        </div>
        <!-- /top navigation -->

        <!-- modal changepassword -->
<div class="modal fade change-password" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-ls">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
        </button>
        <h4 class="modal-title" id="myModalLabel">Change Password</h4>
      </div>
      <div class="modal-body">
      <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" method="post" enctype="multipart/form-data" action="<?php echo site_url(). "/user/changePassword" ?>">
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Last Password <span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="password" id="password" name="password" required="required" class="form-control col-md-7 col-xs-12">
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">New Password <span class="required">*</span>
          </label>
        <div class="col-md-6 col-sm-6 col-xs-12">
          <input type="password" id="new_password" name="new_password" required="required" class="form-control col-md-7 col-xs-12">
        </div>
        </div>
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Re-type Password <span class="required">*</span>
          </label>
        <div class="col-md-6 col-sm-6 col-xs-12">
          <input type="password" id="retype" name="retype" required="required" class="form-control col-md-7 col-xs-12">
        </div>
        </div>
        
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      <button type="submit" class="btn btn-primary">Save changes</button>
    </div>
    </form>
  </div>
  </div>
</div>
