<!-- footer content -->
<footer>
          <div class="pull-right">
            Bogang Development. Gentelella - Bootstrap Admin Template by <a href="https://colorlib.com">Colorlib</a>
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- SCRIPT UNTUK MODAL ALERT -->
    <div id="warningmodal" class="modal fade bs-example-modal-md" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-md">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
              </button>
              <h5 class="modal-title" id="myModalLabel">Application Warning</h5>
            </div>
            <div class="modal-body">
              <h5><?php echo $this->session->flashdata('message'); ?></h5>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
    </div>
    
    <!-- jQuery -->
    <script src="<?php echo base_url(). "vendors/" ?>jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="<?php echo base_url(). "vendors/" ?>bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="<?php echo base_url(). "vendors/" ?>fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="<?php echo base_url(). "vendors/" ?>nprogress/nprogress.js"></script>
    <!-- Chart.js -->
    <script src="<?php echo base_url(). "vendors/" ?>Chart.js/dist/Chart.min.js"></script>
    <!-- gauge.js -->
    <script src="<?php echo base_url(). "vendors/" ?>gauge.js/dist/gauge.min.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="<?php echo base_url(). "vendors/" ?>bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="<?php echo base_url(). "vendors/" ?>iCheck/icheck.min.js"></script>
    <!-- Skycons -->
    <script src="<?php echo base_url(). "vendors/" ?>skycons/skycons.js"></script>
    <!-- Flot -->
    <script src="<?php echo base_url(). "vendors/" ?>Flot/jquery.flot.js"></script>
    <script src="<?php echo base_url(). "vendors/" ?>Flot/jquery.flot.pie.js"></script>
    <script src="<?php echo base_url(). "vendors/" ?>Flot/jquery.flot.time.js"></script>
    <script src="<?php echo base_url(). "vendors/" ?>Flot/jquery.flot.stack.js"></script>
    <script src="<?php echo base_url(). "vendors/" ?>Flot/jquery.flot.resize.js"></script>
    <!-- Flot plugins -->
    <script src="<?php echo base_url(). "vendors/" ?>flot.orderbars/js/jquery.flot.orderBars.js"></script>
    <script src="<?php echo base_url(). "vendors/" ?>flot-spline/js/jquery.flot.spline.min.js"></script>
    <script src="<?php echo base_url(). "vendors/" ?>flot.curvedlines/curvedLines.js"></script>
    <!-- DateJS -->
    <script src="<?php echo base_url(). "vendors/" ?>DateJS/build/date.js"></script>
    <!-- JQVMap -->
    <script src="<?php echo base_url(). "vendors/" ?>jqvmap/dist/jquery.vmap.js"></script>
    <script src="<?php echo base_url(). "vendors/" ?>jqvmap/dist/maps/jquery.vmap.world.js"></script>
    <script src="<?php echo base_url(). "vendors/" ?>jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="<?php echo base_url(). "vendors/" ?>moment/min/moment.min.js"></script>
    <script src="<?php echo base_url(). "vendors/" ?>bootstrap-daterangepicker/daterangepicker.js"></script>
    <!-- Data-Table -->
    <script src="<?php echo base_url(). "vendors/" ?>datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(). "vendors/" ?>datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo base_url(). "vendors/" ?>datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo base_url(). "vendors/" ?>datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="<?php echo base_url(). "vendors/" ?>datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="<?php echo base_url(). "vendors/" ?>datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php echo base_url(). "vendors/" ?>datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="<?php echo base_url(). "vendors/" ?>datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="<?php echo base_url(). "vendors/" ?>datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="<?php echo base_url(). "vendors/" ?>datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?php echo base_url(). "vendors/" ?>datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="<?php echo base_url(). "vendors/" ?>datatables.net-scroller/js/dataTables.scroller.min.js"></script>

    <script> function del_confirm() { var x = confirm("Are you sure you want to delete?"); if (x) return true; else return false; } </script>
    <script>function reset() { var x = confirm("Are you sure you want to reset the password?");if (x) return true; else return false; } </script>
    <script>function act_confirm() { var x = confirm("Are you sure you want to do this task?");if (x) return true; else return false; } </script>

    <?php if($this->session->flashdata('message') != NULL) { ?> <script type="text/javascript"> $(window).on('load',function(){ $('#warningmodal').modal('show'); }); </script> <?php } ?>

    <!-- Custom Theme Scripts -->
    <script src="<?php echo base_url(). "build/" ?>js/custom.min.js"></script>
	
  </body>
</html>