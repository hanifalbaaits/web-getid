<?php 

class Cluster extends CI_Controller{

    private $otorisasi = "f13583efdb91a190abf6ec0c84cedd81";

    function __construct(){
        date_default_timezone_get('Asia/Jakarta');

        parent::__construct();
        $this->load->helper('url');
        $this->session_key = $this->config->item('session-key');
        $this->load->model("access_model");
        $this->load->model("customer_model");      
        $this->load->model("TapCluster_model");  
    }

    function index(){
        if($this->session->userdata('logcode') == $this->session_key) {
            if($this->session->userdata('role') != "7") {
                $menus['menus'] = $this->access_model->getByRole($this->session->userdata('role'));
                $data["customers"] = $this->customer_model->getByRole(8); //customer
                $this->load->view('frame/a_header');
                $this->load->view('frame/b_nav',$menus);
                $this->load->view('page/clustersecurity/cluster',$data);
                $this->load->view('frame/d_footer');
            } else {
                $this->session->set_flashdata('message', " Anda tidak memeliki akses ke halaman tersebut! ");
                redirect('home');
            }
        } else {
            $this->session->set_flashdata('message', " Login Terlebih dahulu! ");
            redirect('login');
        }
    }

    function history(){
        if($this->session->userdata('logcode') == $this->session_key) {
            $menus['menus'] = $this->access_model->getByRole($this->session->userdata('role'));
            if($this->session->userdata('role') != "8") {            
                $data["history"] = $this->TapCluster_model->getAll(); //customer
            } else {
                $data["history"] = $this->TapCluster_model->getByUID($this->session->userdata('uid')); //customer
            }
            $this->load->view('frame/a_header');
            $this->load->view('frame/b_nav',$menus);
            $this->load->view('page/clustersecurity/cluster_history',$data);
            $this->load->view('frame/d_footer');

        } else {
            $this->session->set_flashdata('message', " Login Terlebih dahulu! ");
            redirect('login');
        }
    }

    function nodemcu(){
        $token = $this->input->get('token');
        $UID = $this->input->get('UID');
        $door = $this->input->get('door');
        
        if($token == null || $UID == null || $door==null){
            echo "FIELD ANDA TIDAK ADA";return;
         } 
         if ($token != $this->otorisasi){
             echo "TOKEN SALAH!";return;
         }
         if( $this->customer_model->getByUID($UID) == null){
             echo "UID TIDAK TERDAFTAR"; return;
         }
 
         $dumy = $this->TapCluster_model->getLastByUID($UID);
         if ($dumy == null || $dumy->status==1){
             $this->TapCluster_model->save($UID,0,$door);
             echo $UID."|".$door."|Created";
 
         } else {
             $this->TapCluster_model->update($dumy->index_tap,1,$door);
             echo $UID."|".$door."|Updated";
         }
    }
}
?>