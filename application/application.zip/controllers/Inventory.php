<?php 

class Inventory extends CI_Controller{

    private $otorisasi = "f13583efdb91a190abf6ec0c84cedd81";
    
    function __construct(){
        date_default_timezone_get('Asia/Jakarta');

        parent::__construct();
        $this->load->helper('url');
        $this->load->model('access_model');
        $this->load->model('inventory_model');
        $this->load->model("TapInventory_model");
        $this->session_key = $this->config->item('session-key');
    }

    function index(){
        if($this->session->userdata('logcode') == $this->session_key) {
            if($this->session->userdata('role') != "8") {
                $menus['menus'] = $this->access_model->getByRole($this->session->userdata('role'));
                $data["inventory"] = $this->inventory_model->getAll();
                $this->load->view('frame/a_header');
                $this->load->view('frame/b_nav',$menus);
                $this->load->view('page/inventory/inventory',$data);
                $this->load->view('frame/d_footer');
            } else {
                $this->session->set_flashdata('message', " Anda tidak memeliki akses ke halaman tersebut! ");
                redirect('home');
            }
        } else {
            $this->session->set_flashdata('message', " Login Terlebih dahulu! ");
            redirect('login');
        }
    }

    function history(){
        if($this->session->userdata('logcode') == $this->session_key) {
            if($this->session->userdata('role') != "8") {
                $menus['menus'] = $this->access_model->getByRole($this->session->userdata('role'));
                $data["history"] = $this->TapInventory_model->getAll(); //customer
                $this->load->view('frame/a_header');
                $this->load->view('frame/b_nav',$menus);
                $this->load->view('page/inventory/inventory_history',$data);
                $this->load->view('frame/d_footer');
            } else {
                $this->session->set_flashdata('message', " Anda tidak memeliki akses ke halaman tersebut! ");
                redirect('home');
            }
        } else {
            $this->session->set_flashdata('message', " Login Terlebih dahulu! ");
            redirect('login');
        }
    }

    function getInventory(){
        if($this->session->userdata('logcode') != $this->session_key) {
            $this->session->set_flashdata('message', " Login Terlebih dahulu! ");
            redirect('login');
        }

        $kd = $this->input->post('kd_barang');
        $data = $this->inventory_model->getById($kd);
        echo $data->kd_barang . "|" .
                 $data->uid_card . "|" .
                 $data->kd_jenis . "|" .
                 $data->kd_lokasi . "|" .
                 $data->nama . "|" .
                 $data->merk . "|" . 
                 $data->tipe . "|" . 
                 $data->unit . "|" . 
                 $data->value 
        ;
    }

    function addInventory(){
        if($this->session->userdata('logcode') != $this->session_key) {
            $this->session->set_flashdata('message', " Login Terlebih dahulu! ");
            redirect('login');
        }

        $uid_card = $this->input->post('uid');
        $kd_jenis = $this->input->post('jenis');
        $kd_lokasi = $this->input->post('lokasi');
        $nama = $this->input->post('nama');
        $merk = $this->input->post('merk');
        $tipe = $this->input->post('tipe');
        $unit = $this->input->post('unit');
        $value = $this->input->post('value');
        
        if($this->inventory_model->getByUID($uid_card)){
            $this->session->set_flashdata('message', " Maaf UID tersebut sudah terdaftar! ");
            redirect('inventory');    
        } 

        $this->inventory_model->save($uid_card,$kd_jenis,$kd_lokasi,$nama,$merk,$tipe,$unit,$value);
        $this->session->set_flashdata('message', " Inventory $nama has succesfully created");
        redirect("inventory"); 
    }

    function editInventory(){
        if($this->session->userdata('logcode') != $this->session_key) {
            $this->session->set_flashdata('message', " Login Terlebih dahulu! ");
            redirect('login');
        }

        $kd_barang = $this->input->post('edit-kd');
        $uid_card = $this->input->post('edit-uid');
        $kd_jenis = $this->input->post('edit-jenis');
        $kd_lokasi = $this->input->post('edit-lokasi');
        $nama = $this->input->post('edit-nama');
        $merk = $this->input->post('edit-merk');
        $tipe = $this->input->post('edit-tipe');
        $unit = $this->input->post('edit-unit');
        $value = $this->input->post('edit-value');

        $this->inventory_model->update($kd_barang,$uid_card,$kd_jenis,$kd_lokasi,$nama,$merk,$tipe,$unit,$value);
        $this->session->set_flashdata('message', " Inventory $nama has updated");
        redirect("inventory"); 
    }

    function deleteInventory($username){
        $this->user_model->delete($username);
        $this->customer_model->delete($username);
        $this->session->set_flashdata('message', " Inventory $username has ben deleted");
        redirect("user"); 
    }

    function nodemcu(){
        $token = $this->input->get('token');
        $UID = $this->input->get('UID');

        if($token == null || $UID == null ){
            echo "FIELD ANDA TIDAK ADA";return;
         } 
         if ($token != $this->otorisasi){
             echo "TOKEN SALAH!";return;
         }

         $dumy = $this->inventory_model->getByUID($UID);
         if ($dumy == null){
            echo "TIDAK DIKENAL";
        } else {
            $this->TapInventory_model->save($UID,0);
            echo $dumy->kd_lokasi;
        }   
    }
}
?>