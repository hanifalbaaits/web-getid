<?php

class Home extends CI_Controller{

    function __construct(){
    date_default_timezone_get('Asia/Jakarta');

        parent::__construct();
        
        $this->load->helper('url');
		$this->load->helper('form');
        $this->load->library('session');
        $this->load->model("User_model");
        $this->load->model("Access_model");
        $this->load->model("Customer_model");
        $this->load->model("TapInventory_model");
        $this->load->model("TapCluster_model");  
        $this->load->model("TapBoarding_model");
        $this->load->model("Hcage_model");
        $this->load->model("Scage_model");
        $this->load->model("Hplant_model");
        $this->load->model("Hcolor_model");
        $this->load->model("Scolor_model");

        $this->session_key = $this->config->item('session-key');

        if($this->session->userdata('logcode') !=  $this->session_key){
            $this->session->set_flashdata('message', " Login Terlebih dahulu! ");
            redirect('login');
        }
    }

    function index() {
        if($this->session->userdata('role') == "2") {
            if($this->session->flashdata('message') != null){
                $this->session->set_flashdata('message', "Anda tidak punya akses ke halaman tersebut");
            }
            redirect('home/inventory');
        } else if($this->session->userdata('role') == "3") {
            if($this->session->flashdata('message') != null){
                $this->session->set_flashdata('message', "Anda tidak punya akses ke halaman tersebut");
            }
            redirect('home/clustersecurity');
        } else if($this->session->userdata('role') == "4") {
            if($this->session->flashdata('message') != null){
                $this->session->set_flashdata('message', "Anda tidak punya akses ke halaman tersebut");
            }
            redirect('home/boardinghouse');
        } else if($this->session->userdata('role') == "5") {
            if($this->session->flashdata('message') != null){
                $this->session->set_flashdata('message', "Anda tidak punya akses ke halaman tersebut");
            }
            redirect('home/plantiot');
        } else if($this->session->userdata('role') == "6") {
            if($this->session->flashdata('message') != null){
                $this->session->set_flashdata('message', "Anda tidak punya akses ke halaman tersebut");
            }
            redirect('home/smartcage');
        } else if($this->session->userdata('role') == "7") {
            if($this->session->flashdata('message') != null){
                $this->session->set_flashdata('message', "Anda tidak punya akses ke halaman tersebut");
            }
            redirect('home/filtercolor');
        } else if($this->session->userdata('role') == "1") {
            if($this->session->flashdata('message') != null){
                $this->session->set_flashdata('message', "Anda tidak punya akses ke halaman tersebut");
            }
            redirect('home/dashboard');
        }else {
            if($this->session->flashdata('message') != null){
                $this->session->set_flashdata('message', "Anda tidak punya akses ke halaman tersebut");
            }
            redirect('home/clustersecurity'); //ganti disini sesuai kan customer nya 
        }
    }

    // function  main(){      
    //     $menus['menus'] = $this->Access_model->getByRole($this->session->userdata('role'));
    //     $this->load->view('frame/a_header');
    //     $this->load->view('frame/b_nav',$menus);
    //     $this->load->view('page/main');
    //     $this->load->view('frame/d_footer');      
    // }

    function dashboard() {
        if($this->session->userdata('role') == "1") {
            $data['users'] = $this->User_model->getAll();
            $menus['menus'] = $this->Access_model->getByRole($this->session->userdata('role'));
            $this->load->view('frame/a_header');
            $this->load->view('frame/b_nav',$menus);
            $this->load->view('page/dashboard',$data);
            $this->load->view('frame/d_footer');      
        }
        else {
            $this->session->set_flashdata('message', "Anda tidak punya akses ke halaman tersebut");
            redirect('home');
        }
    }

    function inventory() {
        if($this->session->userdata('role') == "2" || $this->session->userdata('role') == "1") {
            $menus['menus'] = $this->Access_model->getByRole($this->session->userdata('role'));
            $history = $this->TapInventory_model->getforDashboard();
            
            $cap_food = 50; //floor1
            $cap_electronic = 50; //floor2
            $food = [];
            $electronic = [];
            foreach ($history as $key => $value) {
                if($value->kd_jenis == "KD001"){
                    $food[] = $value;
                } else {
                    $electronic[] = $value;
                }

                if($key == 0){
                    $time_update = $value->time_in;
                }
            }

            $persenFood = count($food) / $cap_food * 100 ;
            $persenElectronic = count($electronic) / $cap_electronic * 100 ;
            $persenTotal = ($persenFood + $persenElectronic) / 2 ;

            $data['history'] = $history;
            $data['food'] = count($food);
            $data['electronic'] = count($electronic);
            $data['persenFood'] = $persenFood;
            $data['persenElectronic'] = $persenElectronic;
            $data['persenTotal'] = $persenTotal;
            $data['time_update'] = $time_update;

            $this->load->view('frame/a_header');
            $this->load->view('frame/b_nav',$menus);
            $this->load->view('page/inventory/dashboard',$data);
            $this->load->view('frame/d_footer');
        }
        else {
            $this->session->set_flashdata('message', "Anda tidak punya akses ke halaman tersebut");
            redirect('home');
        }
    }

    function clustersecurity() {
        if($this->session->userdata('role') == "3" || $this->session->userdata('role') == "1" || 
            $this->session->userdata('role') == "8") {    
            $menus['menus'] = $this->Access_model->getByRole($this->session->userdata('role'));
            $history = $this->TapCluster_model->getforDashboard(); //customer
            $customers = $this->Customer_model->getByRole('8');
     
            $in = [];
            $out = [];
            foreach ($customers as $key => $value) {
                $dumy = $this->TapCluster_model->getLastByUID($value->uid_card);
                if($dumy != null){
                    if($dumy->status==0){
                        $in[] = $dumy;
                    } else {
                        $out[] = $dumy;
                    }
                }
            }    

            foreach ($history as $key =>$val) {
                if($key == 0){
                    $last = $val;
                    break;
                }
            }

            $data['history'] = $history;
            $data['in'] = count($in);
            $data['out'] = count($out);
            $data['last'] = $last;
            $data['all'] = count($customers);
            $this->load->view('frame/a_header');
            $this->load->view('frame/b_nav',$menus);
            $this->load->view('page/clustersecurity/dashboard',$data);
            $this->load->view('frame/d_footer');
        }
        else {
            $this->session->set_flashdata('message', "Anda tidak punya akses ke halaman tersebut");
            redirect('home');
        }
    }

    function boardinghouse() {
        if($this->session->userdata('role') == "4" || $this->session->userdata('role') == "1"
            || $this->session->userdata('role') == "8" ) { 
            
            $menus['menus'] = $this->Access_model->getByRole($this->session->userdata('role'));
            $history = $this->TapBoarding_model->getforDashboard(); //customer
            $customers = $this->Customer_model->getByRole('8');
     
            $in = [];
            $out = [];
            foreach ($customers as $key => $value) {
                $dumy = $this->TapBoarding_model->getLastByUID($value->uid_card);
                if($dumy != null){
                    if($dumy->status==0){
                        $in[] = $dumy;
                    } else {
                        $out[] = $dumy;
                    }

                    if($dumy->door==0){ //door 0 kamar melati
                        $melati = $dumy;
                    } else {
                        $mawar = $dumy;
                    }
                }
            }    

            foreach ($history as $key =>$val) {
                if($key == 0){
                    $last = $val;
                    break;
                }
            }

            $data['history'] = $history;
            $data['in'] = count($in);
            $data['out'] = count($out);
            $data['melati'] = $melati;
            $data['mawar'] = $mawar;
            $data['last'] = $last;
            $data['all'] = count($customers);
            $this->load->view('frame/a_header');
            $this->load->view('frame/b_nav',$menus);
            $this->load->view('page/boardinghouse/dashboard',$data);
            $this->load->view('frame/d_footer');
        }
        else {
            $this->session->set_flashdata('message', "Anda tidak punya akses ke halaman tersebut");
            redirect('home');
        }
    }

    function plantiot() {
        if($this->session->userdata('role') == "5" || $this->session->userdata('role') == "1") { 
            $menus['menus'] = $this->Access_model->getByRole($this->session->userdata('role'));
            $history = $this->Hplant_model->getforDashboard(); //customer
            
            $suhu = null;
            $kelembaban = null;
            $ldr = null;
             foreach ($history as $key => $value) {
                if($suhu !=null && $kelembaban !=null && $ldr !=null){
                    break;
                }
                if($value->id_sensor=="1"){ //ini sensor suhu
                    $suhu = $value;
                } else if ($value->id_sensor=="2"){ //ini sensor kelembaban
                    $kelembaban = $value;
                } else if ($value->id_sensor=="3"){ //ini sensor ldr
                    $ldr= $value;
                }
            }

            $data["history"] = $history;
            $data["suhu"] = $suhu;
            $data["kelembaban"] = $kelembaban;
            $data["ldr"] = $ldr;
            
            $this->load->view('frame/a_header');
            $this->load->view('frame/b_nav',$menus);
            $this->load->view('page/plant/dashboard',$data);
            $this->load->view('frame/d_footer');
        }
        else {
            $this->session->set_flashdata('message', "Anda tidak punya akses ke halaman tersebut");
            redirect('home');
        }
    }

    function smartcage() {
        if($this->session->userdata('role') == "6" || $this->session->userdata('role') == "1"){ 
            $menus['menus'] = $this->Access_model->getByRole($this->session->userdata('role'));
            $hcsr = $this->Hcage_model->getLastById(1);
            $temp = $this->Hcage_model->getLastById(2);
            $control = $this->Scage_model->getControl();

            $tinggiMax = 30;
            $tinggiNow = $hcsr->value;
            $cap_persen = ($tinggiNow / $tinggiMax ) * 100;

            $data["hcsr"] = $hcsr;
            $data["temp"] = $temp;
            $data["persen"] = $cap_persen;
            $data["servo"] = $control[0];
            $data["motor"] = $control[1];
            $data["led"] = $control[2];
            $this->load->view('frame/a_header');
            $this->load->view('frame/b_nav',$menus);
            $this->load->view('page/smartcage/dashboard',$data);
            $this->load->view('frame/d_footer');
        }
        else {
            $this->session->set_flashdata('message', "Anda tidak punya akses ke halaman tersebut");
            redirect('home');
        }
    }

    function filtercolor() {
        if($this->session->userdata('role') == "7" || $this->session->userdata('role') == "1") {    
            $menus['menus'] = $this->Access_model->getByRole($this->session->userdata('role'));
            $history = $this->Hcolor_model->getforToday(); //customer
            $m_kecil = [];
            $m_besar = [];
            $h_kecil = [];
            $h_besar = [];
            $his = [];
            foreach ($history as $key =>$val) {
                $nm_size = $this->Scolor_model->getByAlias($val->size_status)->description;
                $nm_color = $this->Scolor_model->getByAlias($val->color_status)->description;
                $object = (object) ['index_s'=>$val->index_s,
                'size_status'=>$val->size_status,
                'color_status'=>$val->color_status,
                'nm_size'=>$nm_size,
                'nm_color'=>$nm_color,
                'time_update'=>$val->time_update
                ];
                $his[] = $object;
                
                if($val->size_status == "SZ000" && $val->color_status== "CR000"){
                    $m_kecil[] = $val;
                } else if($val->size_status == "SZ001" && $val->color_status== "CR000"){
                    $m_besar[] = $val;
                } else if($val->size_status == "SZ000" && $val->color_status== "CR001"){
                    $h_kecil[] = $val;
                } else if($val->size_status == "SZ001" && $val->color_status== "CR001"){
                    $h_besar[] = $val;
                } else {
                    continue;
                }
            }
            $data['history'] = $his;
            $data['m_kecil'] = count($m_kecil);
            $data['m_besar'] = count($m_besar);
            $data['h_kecil'] = count($h_kecil);
            $data['h_besar'] = count($h_besar);

            $this->load->view('frame/a_header');
            $this->load->view('frame/b_nav',$menus);
            $this->load->view('page/filtercolor/dashboard',$data);
            $this->load->view('frame/d_footer');
        }
        else {
            $this->session->set_flashdata('message', "Anda tidak punya akses ke halaman tersebut");
            redirect('home');
        }
    }
}
?>