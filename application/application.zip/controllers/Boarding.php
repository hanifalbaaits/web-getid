<?php 

class Boarding extends CI_Controller{

    private $otorisasi = "f13583efdb91a190abf6ec0c84cedd81";

    function __construct(){
        date_default_timezone_get('Asia/Jakarta');

        parent::__construct();
        $this->load->helper('url');
        $this->session_key = $this->config->item('session-key');
        $this->load->model("access_model");
        $this->load->model("customer_model"); 
        $this->load->model("TapBoarding_model");       
    }

    function index(){
        if($this->session->userdata('logcode') == $this->session_key) {
            if($this->session->userdata('role') != "8") {
            $menus['menus'] = $this->access_model->getByRole($this->session->userdata('role'));
            $data["customers"] = $this->customer_model->getByRole(8); //customer
            $this->load->view('frame/a_header');
            $this->load->view('frame/b_nav',$menus);
            $this->load->view('page/boardinghouse/boarding',$data);
            $this->load->view('frame/d_footer');
            } else {
                $this->session->set_flashdata('message', " Anda tidak memeliki akses ke halaman tersebut! ");
                redirect('home');
            }
        } else {
            $this->session->set_flashdata('message', " Login Terlebih dahulu! ");
            redirect('login');
        }
    }

    function history(){
        if($this->session->userdata('logcode') == $this->session_key) {
            $menus['menus'] = $this->access_model->getByRole($this->session->userdata('role'));
            if($this->session->userdata('role') != "8") {
                $data["history"] = $this->TapBoarding_model->getAll(); //customer
            } else {
                $data["history"] = $this->TapBoarding_model->getByUID($this->session->userdata('uid'));
            }
            $this->load->view('frame/a_header');
            $this->load->view('frame/b_nav',$menus);
            $this->load->view('page/boardinghouse/boarding_history',$data);
            $this->load->view('frame/d_footer');

        } else {
            $this->session->set_flashdata('message', " Login Terlebih dahulu! ");
            redirect('login');
        }
    }

    function nodemcu(){
        $token = $this->input->get('token');
        $UID = $this->input->get('UID');
        $count =$this->input->get('count');

        if($token == null || $UID == null || $count==null){
           echo "FIELD ANDA TIDAK ADA";return;
        } 
        if ($token != $this->otorisasi){
            echo "TOKEN SALAH!";return;
        }
        if( $this->customer_model->getByUID($UID) == null){
            echo "UID TIDAK TERDAFTAR"; return;
        }

        $dumy = $this->TapBoarding_model->getLastByUID($UID);
        if ($dumy == null || $dumy->status==1){
            $this->TapBoarding_model->save($UID,0,$count);
            echo $UID."|".$count."|Created";

        } else {
            $this->TapBoarding_model->update($dumy->index_tap,1);
            echo $UID."|".$count."|Updated";
        }      
    }
}
?>