<?php 

class Role extends CI_Controller{
    function __construct(){
        date_default_timezone_get('Asia/Jakarta');

        parent::__construct();
        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->library('session');
        $this->load->model("role_model");
        $this->load->model('access_model');
        $this->session_key = $this->config->item('session-key');

        if($this->session->userdata('logcode') != $this->session_key){
            $this->session->set_flashdata('message', " Login Terlebih dahulu! ");
            redirect('login');
        } 

        if($this->session->userdata('role') == "8"){
            $this->session->set_flashdata('message', " Anda tidak memeliki akses ke halaman tersebut! ");
            redirect('home');
        }
    }

    function index(){
        $menus['menus'] = $this->access_model->getByRole($this->session->userdata('role'));
        $data["roles"] = $this->role_model->getAll();
        $this->load->view('frame/a_header');
        $this->load->view('frame/b_nav',$menus);
        $this->load->view('page/role',$data);
        $this->load->view('frame/d_footer');
    }

    function addRole(){
        $nm_role = $this->input->post('nm_role');    
        $this->role_model->save($nm_role);
        $this->session->set_flashdata('message', " Role $nm_role has succesfully created");
        redirect("role"); 
    }

    function editRole(){
        $id_role = $this->input->post('edit-id_role');
        $nm_role = $this->input->post('edit-nm_role');
        $this->role_model->update($id_role,$nm_role);
        $this->session->set_flashdata('message', " Role with id $id_role has updated");
        redirect("role"); 
    }

    function deleteRole($id_role){
        $this->role_model->delete($id_role);
        $this->session->set_flashdata('message', " Role with id $id_role has deleted");
        redirect("role"); 
    }

    function getRole(){
        $id_role = $this->input->post('id_role');
        $data = $this->role_model->getById($id_role);
        echo $data->id_role . "|" .
                 $data->nm_role . "|" .
                 $data->status . "|" .
                 $data->created_date . "|" . 
                 $data->update_date 
        ;
    }

    function changeStatus(){
        $id_role = $this->uri->segment('3');
        $status = $this->uri->segment('4');
        $this->role_model->status($id_role,$status);
        if($status == 0){
            $this->session->set_flashdata('message', " Role with id $id_role has banned");
        } else {
            $this->session->set_flashdata('message', " Role with id $id_role has Active");
        }
        redirect("role");
    }
}
?>