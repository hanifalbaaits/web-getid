<?php 

class Customers extends CI_Controller{
    function __construct(){
        date_default_timezone_get('Asia/Jakarta');

        parent::__construct();
        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->library('session');
        $this->load->model('access_model');
        $this->load->model('customer_model');
        $this->session_key = $this->config->item('session-key');

        if($this->session->userdata('logcode') != $this->session_key){
            $this->session->set_flashdata('message', " Login Terlebih dahulu! ");
            redirect('login');
        } 

        if($this->session->userdata('role') == "8"){
            $this->session->set_flashdata('message', " Anda tidak memeliki akses ke halaman tersebut! ");
            redirect('home');
        }
    }

    function index(){
        $menus['menus'] = $this->access_model->getByRole($this->session->userdata('role'));
        $data["customers"] = $this->customer_model->getAll();
        $this->load->view('frame/a_header');
        $this->load->view('frame/b_nav',$menus);
        $this->load->view('page/customers',$data);
        $this->load->view('frame/d_footer');
    }

    function editCustomer(){
        $username = $this->input->post('edit-username');
        $nm_depan = $this->input->post('edit-nm_depan');
        $nm_belakang = $this->input->post('edit-nm_belakang');
        $email = $this->input->post('edit-email');
        $phone = $this->input->post('edit-phone');
        $alamat = $this->input->post('edit-alamat');
        $jk = $this->input->post('edit-j_kelamin');
        $pekerjaan = $this->input->post('edit-pekerjaan');
        $no_ktp = $this->input->post('edit-no_ktp');
        $url = $this->input->post('edit-url');
        $uid = $this->input->post('edit-uid_card');
        $this->customer_model->update($username,$nm_depan,$nm_belakang,$email,$phone,$alamat,$jk,$pekerjaan,$no_ktp,$url,$uid);
        $this->session->set_flashdata('message', " Customer with username $username has updated");
        redirect("customers"); 
    }

    function getCustomer(){
        $username = $this->input->post('username');
        $data = $this->customer_model->getByUsername($username);
        echo $data->username . "|" .
                 $data->nm_depan . "|" .
                 $data->nm_belakang . "|" .
                 $data->email . "|" .
                 $data->phone . "|" .
                 $data->alamat . "|" . 
                 $data->j_kelamin . "|" . 
                 $data->pekerjaan . "|" . 
                 $data->no_ktp . "|" . 
                 $data->uid_card . "|" . 
                 $data->url_profile 
        ;
    }
}
?>