<?php 

class Filtercolor extends CI_Controller{

    private $otorisasi = "f13583efdb91a190abf6ec0c84cedd81";

    function __construct(){
        date_default_timezone_get('Asia/Jakarta');

        parent::__construct();
        $this->load->helper('url');
        $this->session_key = $this->config->item('session-key');
        $this->load->model('access_model');
        $this->load->model('Scolor_model');
        $this->load->model('Hcolor_model');
    }

    function index(){
        if($this->session->userdata('logcode') == $this->session_key) {
            if($this->session->userdata('role') != "8") {
                $menus['menus'] = $this->access_model->getByRole($this->session->userdata('role'));
                $data["scolor"] = $this->Scolor_model->getAll();
        
                $this->load->view('frame/a_header');
                $this->load->view('frame/b_nav',$menus);
                $this->load->view('page/filtercolor/fcolor',$data);
                $this->load->view('frame/d_footer');
            } else {
                $this->session->set_flashdata('message', " Anda tidak memeliki akses ke halaman tersebut! ");
                redirect('home');
            }
        } else {
            $this->session->set_flashdata('message', " Login Terlebih dahulu! ");
            redirect('login');
        }
    }

    function history(){
        if($this->session->userdata('logcode') == $this->session_key) {
            if($this->session->userdata('role') != "8") {
                $menus['menus'] = $this->access_model->getByRole($this->session->userdata('role'));
                $dcolor = $this->hcolor_model->getAll();
                $his = [];
                foreach ($dcolor as $key => $value) {
                    $nm_size = $this->Scolor_model->getByAlias($value->size_status)->description;
                    $nm_color = $this->Scolor_model->getByAlias($value->color_status)->description;
                    $object = (object) ['index_s'=>$value->index_s,
                    'size_status'=>$value->size_status,
                    'color_status'=>$value->color_status,
                    'nm_size'=>$nm_size,
                    'nm_color'=>$nm_color,
                    'time_update'=>$value->time_update
                ];
                    $his[] = $object;
                }
                $data["hcolor"] = $his;
                $this->load->view('frame/a_header');
                $this->load->view('frame/b_nav',$menus);
                $this->load->view('page/filtercolor/color_history',$data);
                $this->load->view('frame/d_footer');
            } else {
                $this->session->set_flashdata('message', " Anda tidak memeliki akses ke halaman tersebut! ");
                redirect('home');
            }
        } else {
            $this->session->set_flashdata('message', " Login Terlebih dahulu! ");
            redirect('login');
        }
    }

    function addScolor(){
        $alias = $this->input->post('alias');   
        $nama = $this->input->post('nama'); 
        $jenis = $this->input->post('jenis'); 
        $description = $this->input->post('description');  
        
        // echo $alias.$nama.$jenis.$description;
        $this->Scolor_model->save($alias,$nama,$jenis,$description);
        $this->session->set_flashdata('message', " Data $alias has succesfully created");
        redirect("filtercolor"); 
    }

    function editScolor(){
        $id = $this->input->post('edit-id');
        $alias = $this->input->post('edit-alias');   
        $nama = $this->input->post('edit-nama'); 
        $jenis = $this->input->post('edit-jenis'); 
        $description = $this->input->post('edit-description');  

        // echo $id.$alias.$nama.$jenis.$description;
        $this->Scolor_model->update($id,$alias,$nama,$jenis,$description);
        $this->session->set_flashdata('message', "  Data $alias has updated");
        redirect("filtercolor"); 
    }

    function deleteScolor($id){
        $this->Scolor_model->delete($id);
        $this->session->set_flashdata('message', "  Data $alias has deleted");
        redirect("filtercolor"); 
    }

    function getScolor(){
        $id = $this->input->post('id');
        $data = $this->Scolor_model->getById($id);
        echo $data->id . "|" .
                 $data->alias . "|" .
                 $data->nama . "|" .
                 $data->jenis . "|" . 
                 $data->description 
        ;
    }

    function getScolorByAlias($alias){
        $data = $this->Scolor_model->getByAlias($alias);
        echo $data->description;
    }

    function nodemcu(){
        $token = $this->input->get('token');
        $size = $this->input->get('size');
        $color = $this->input->get('color');

        if($token == null || $size == null || $color==null){
            echo "FIELD ANDA TIDAK ADA"; return;
         } 
         if ($token != $this->otorisasi){
             echo "TOKEN SALAH!"; return;
         }

        $this->Hcolor_model->save($size,$color);
        echo "Data Insert Filter Color";
    }
}
?>