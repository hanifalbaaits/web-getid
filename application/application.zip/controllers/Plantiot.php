<?php 

class Plantiot extends CI_Controller{
    
    private $otorisasi = "f13583efdb91a190abf6ec0c84cedd81";

    function __construct(){
        date_default_timezone_get('Asia/Jakarta');

        parent::__construct();
        $this->load->helper('url');
        $this->session_key = $this->config->item('session-key');
        $this->load->model('access_model');
        $this->load->model('splant_model');
        $this->load->model('hplant_model');
    }

    function index(){
        if($this->session->userdata('logcode') == $this->session_key) {
            if($this->session->userdata('role') != "8") {
                $menus['menus'] = $this->access_model->getByRole($this->session->userdata('role'));
                $data["splant"] = $this->splant_model->getAll();
                $this->load->view('frame/a_header');
                $this->load->view('frame/b_nav',$menus);
                $this->load->view('page/plant/plant',$data);
                $this->load->view('frame/d_footer');
            } else {
                $this->session->set_flashdata('message', " Anda tidak memeliki akses ke halaman tersebut! ");
                redirect('home');
            }
        } else {
            $this->session->set_flashdata('message', " Login Terlebih dahulu! ");
            redirect('login');
        }
    }

    function history(){
        if($this->session->userdata('logcode') == $this->session_key) {
            if($this->session->userdata('role') != "8") {
                $menus['menus'] = $this->access_model->getByRole($this->session->userdata('role'));
                $data["hplant"] = $this->hplant_model->getAll();
                $this->load->view('frame/a_header');
                $this->load->view('frame/b_nav',$menus);
                $this->load->view('page/plant/plant_history',$data);
                $this->load->view('frame/d_footer');
            } else {
                $this->session->set_flashdata('message', " Anda tidak memeliki akses ke halaman tersebut! ");
                redirect('home');
            }
        } else {
            $this->session->set_flashdata('message', " Login Terlebih dahulu! ");
            redirect('login');
        }
    }

    function addSplant(){
        $alias = $this->input->post('alias');   
        $nama = $this->input->post('nama'); 
        $jenis = $this->input->post('jenis'); 
        $description = $this->input->post('description');  
        
        // echo $alias.$nama.$jenis.$description;
        $this->splant_model->save($alias,$nama,$jenis,$description);
        $this->session->set_flashdata('message', " Data $alias has succesfully created");
        redirect("plantiot"); 
    }

    function editSplant(){
        $id = $this->input->post('edit-id');
        $alias = $this->input->post('edit-alias');   
        $nama = $this->input->post('edit-nama'); 
        $jenis = $this->input->post('edit-jenis'); 
        $description = $this->input->post('edit-description');  

        // echo $id.$alias.$nama.$jenis.$description;
        $this->splant_model->update($id,$alias,$nama,$jenis,$description);
        $this->session->set_flashdata('message', "  Data $alias has updated");
        redirect("plantiot"); 
    }

    function deleteSplant($id){
        $this->splant_model->delete($id);
        $this->session->set_flashdata('message', "  Data $alias has deleted");
        redirect("plantiot"); 
    }

    function getSplant(){
        $id = $this->input->post('id');
        $data = $this->splant_model->getById($id);
        echo $data->id . "|" .
                 $data->alias . "|" .
                 $data->nama . "|" .
                 $data->jenis . "|" . 
                 $data->description 
        ;
    }

    function nodemcu(){
        $token = $this->input->get('token');
        $temp = $this->input->get('temp');
        $humidity = $this->input->get('humidity');
        $ldr = $this->input->get('ldr');
        
        if($token == null || $temp == null || $humidity == null || $ldr == null){
            echo "FIELD ANDA TIDAK ADA";
        } else if ($token != $this->otorisasi){
            echo "TOKEN SALAH!";
        }
        else {
            $this->hplant_model->save('1',$temp);
            $this->hplant_model->save('2',$humidity);
            $this->hplant_model->save('3',$ldr);
            $respon = "Data Sensor Insert";
            // foreach ($data as $key => $control) {
            //     $respon = $respon.$control->status;
            // }
            echo $respon;
        }
    }
}
?>