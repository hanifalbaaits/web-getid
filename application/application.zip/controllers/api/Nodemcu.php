<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
require APPPATH . '/libraries/Format.php';


use Restserver\Libraries\REST_Controller;

class Nodemcu extends REST_Controller {
    
    function __Construct() {
        parent::__construct();
        date_default_timezone_set("Asia/Jakarta");
        $this->load->helper('url');
    }

    public function inventory_get($id,$token,$door,$time) {
        $token = $this->config->item('secret-key');
		$this->response([
                        'id'=>$id,
                        'token'=>$token,
                        'door'=>$door,
                        'time'=>$time,
                        'token' => $token
                    ],
                    REST_Controller::HTTP_OK);
    redirect("home");
    }
    
    public function clustersecurity_get($uid,$authorization,$door) {
        $token = $this->config->item('secret-key');
		$this->response([
                        'uid'=>$uid,
                        'token'=>$authorization,
                        'door'=>$door
                    ],
                    REST_Controller::HTTP_OK);
    redirect("home");
	}
}	

?>
