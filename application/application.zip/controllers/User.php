<?php 

class User extends CI_Controller{
    function __construct(){
        parent::__construct();
        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->library('session');
        $this->load->model("user_model");
        $this->load->model("role_model");
        $this->load->model("access_model");
        $this->load->model("customer_model");
        $this->session_key = $this->config->item('session-key');

        if($this->session->userdata('logcode') != $this->session_key){
            $this->session->set_flashdata('message', " Login Terlebih dahulu! ");
            redirect('home');
        } 

        if($this->session->userdata('role') == "8"){
            $this->session->set_flashdata('message', " Anda tidak memeliki akses ke halaman tersebut! ");
            redirect('home');
        }
    }

    function index(){ 
        $menus['menus'] = $this->access_model->getByRole($this->session->userdata('role'));
        $data["users"] = $this->user_model->getAll();
        $data["roles"] = $this->role_model->getAll();
        $this->load->view('frame/a_header');
        $this->load->view('frame/b_nav',$menus);
        $this->load->view('page/user', $data);
        $this->load->view('frame/d_footer');
    }

    function addUser(){
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $retype = $this->input->post('retype');
        $role = $this->input->post('role');
    
        if($password != $retype){
          $this->session->set_flashdata('message', " Password tidak sama! ");
          echo "tidak sama password dengan retype";
          redirect("user");  
        } else {

            if ($this->user_model->cek_username($username) == true){
                $this->user_model->save($username,$password,$role);
                $this->customer_model->save($username);
                $this->session->set_flashdata('message', " User $username has succesfully created");
                redirect("user"); 
            } else{
                $this->session->set_flashdata('message', " Username already taken by another user. try different username ! ");
                redirect("user");   
            }

        }
    }

    function editUser(){
        $username = $this->input->post('edit-username');
        $password = $this->input->post('password');
        $retype = $this->input->post('retype');
        $role = $this->input->post('edit_selected-role');

        if($password != $retype){
          $this->session->set_flashdata('message', " Password tidak sama! ");
          redirect("user");  
        } else {
            $this->user_model->update($username,$password,$role);
            $this->session->set_flashdata('message', " User $username has updated");
            redirect("user"); 
        }
    }

    function deleteUser($username){
        $this->user_model->delete($username);
        $this->customer_model->delete($username);
        $this->session->set_flashdata('message', " User $username has ben deleted");
        redirect("user"); 
    }

    function getUser(){
        $username = $this->input->post('username');
        $data = $this->user_model->getByUsername($username);
        echo $data->id_user . "|" .
                 $data->id_role . "|" .
                 $data->username . "|" .
                 $data->login . "|" .
                 $data->status . "|" .
                 $data->created_date . "|" . 
                 $data->update_date 
        ;
    }

    function changeStatus(){
        $username = $this->uri->segment('3');
        $status = $this->uri->segment('4');
        $this->user_model->status($username,$status);
        if($status == 0){
            $this->session->set_flashdata('message', " User $username has ben banned");
        } else {
            $this->session->set_flashdata('message', " User $username has ben Active");
        }
        redirect("user");
    }

    function changePassword(){
        $username = $this->session->userData('username');
        $password = $this->input->post('password');
        $new_password = $this->input->post('new_password');
        $retype = $this->input->post('retype');
        
        if($new_password != $retype){
          $this->session->set_flashdata('message', " Password tidak sama! ");
          redirect("home/dashboard");  
        } else {

            if ($this->user_model->checkOld($username,$password) == true){
                $this->user_model->updatePassword($username,$new_password);
                $this->session->set_flashdata('message', " Password has been change !");
                $this->user_model->login_out($username,"0");
                $this->session->sess_destroy(); 
                redirect('home', 'refresh'); 
            } else{
                $this->session->set_flashdata('message', " Password Wrong ! ");
                redirect("home/dashboard");    
            }

        }
    }
}
?>