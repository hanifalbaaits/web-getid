<?php 

class Test extends CI_Controller{
    function __construct(){
        date_default_timezone_get('Asia/Jakarta');

        parent::__construct();
        $this->load->helper('url');
        $this->load->model("access_model");
        $this->session_key = $this->config->item('session-key');

        if($this->session->userdata('logcode') != $this->session_key){
            $this->session->set_flashdata('message', " Login Terlebih dahulu! ");
            redirect('login');
        }
    }

  
}
?>