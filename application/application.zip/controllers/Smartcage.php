<?php 

class Smartcage extends CI_Controller{
    
    private $otorisasi = "f13583efdb91a190abf6ec0c84cedd81";

    function __construct(){
        date_default_timezone_get('Asia/Jakarta');

        parent::__construct();
        $this->load->helper('url');
        $this->session_key = $this->config->item('session-key');
        $this->load->model('access_model');
        $this->load->model('scage_model');
        $this->load->model('hcage_model');
    }

    function index(){
        if($this->session->userdata('logcode') == $this->session_key) {
            if($this->session->userdata('role') != "8") {
                $menus['menus'] = $this->access_model->getByRole($this->session->userdata('role'));
                $data["scage"] = $this->scage_model->getAll();
                $this->load->view('frame/a_header');
                $this->load->view('frame/b_nav',$menus);
                $this->load->view('page/smartcage/smartcage',$data);
                $this->load->view('frame/d_footer');
            } else {
                $this->session->set_flashdata('message', " Anda tidak memeliki akses ke halaman tersebut! ");
                redirect('home');
            }
        } else {
            $this->session->set_flashdata('message', " Login Terlebih dahulu! ");
            redirect('login');
        }
    }

    function history(){
        if($this->session->userdata('logcode') == $this->session_key) {
            if($this->session->userdata('role') != "8") {
                $menus['menus'] = $this->access_model->getByRole($this->session->userdata('role'));
                $data["hcage"] = $this->hcage_model->getAll();
                $this->load->view('frame/a_header');
                $this->load->view('frame/b_nav',$menus);
                $this->load->view('page/smartcage/cage_history',$data);
                $this->load->view('frame/d_footer');
            } else {
                $this->session->set_flashdata('message', " Anda tidak memeliki akses ke halaman tersebut! ");
                redirect('home');
            }
        } else {
            $this->session->set_flashdata('message', " Login Terlebih dahulu! ");
            redirect('login');
        }
    }

    function addScage(){
        $alias = $this->input->post('alias');   
        $nama = $this->input->post('nama'); 
        $jenis = $this->input->post('jenis'); 
        $description = $this->input->post('description');  
        
        // echo $alias.$nama.$jenis.$description;
        $this->scage_model->save($alias,$nama,$jenis,$description);
        $this->session->set_flashdata('message', " Data $alias has succesfully created");
        redirect("smartcage"); 
    }

    function editScage(){
        $id = $this->input->post('edit-id');
        $alias = $this->input->post('edit-alias');   
        $nama = $this->input->post('edit-nama'); 
        $jenis = $this->input->post('edit-jenis'); 
        $description = $this->input->post('edit-description');  

        // echo $id.$alias.$nama.$jenis.$description;
        $this->scage_model->update($id,$alias,$nama,$jenis,$description);
        $this->session->set_flashdata('message', "  Data $alias has updated");
        redirect("smartcage"); 
    }

    function deleteScage($id){
        $this->scage_model->delete($id);
        $this->session->set_flashdata('message', "  Data $alias has deleted");
        redirect("smartcage"); 
    }

    function getScage(){
        $id = $this->input->post('id');
        $data = $this->scage_model->getById($id);
        echo $data->id . "|" .
                 $data->alias . "|" .
                 $data->nama . "|" .
                 $data->jenis . "|" . 
                 $data->description 
        ;
    }

    function nodemcu(){
        $token = $this->input->get('token');
        $hcsr = $this->input->get('hcsr'); //id sensor 1
        $temp = $this->input->get('temp'); //id sensor 2
        
        if($token == null || $hcsr == null || $temp == null){
            echo "FIELD ANDA TIDAK ADA";
        } else if ($token != $this->otorisasi){
            echo "TOKEN SALAH!";
        }
        else {
            $this->hcage_model->save('1',$hcsr);
            $this->hcage_model->save('2',$temp);
            $data = $this->scage_model->getControl();
            $respon = "";
            //servo //motor //led
            foreach ($data as $key => $control) {
                $respon = $respon.$control->status;
            }
            echo $respon;
        }
    }

    function scheduleOpen(){
        $token = $this->input->get('token');
        $note = "Schedule Open Servo";
        if($token == null){
            echo "FIELD ANDA TIDAK ADA";
        } else if ($token != $this->otorisasi){
            echo "TOKEN SALAH!";
        } else{
            $this->scage_model->saveSchedule($note);
            //update tb controller untuk buka servo
            $this->scage_model->updateControl("1","1","Open");
            echo $note;
        }  
    }

    function scheduleClosed(){
        $token = $this->input->get('token');
        $note = "Schedule Closed Servo";
        if($token == null){
            echo "FIELD ANDA TIDAK ADA";
        } else if ($token != $this->otorisasi){
            echo "TOKEN SALAH!";
        } else{
            $this->scage_model->saveSchedule($note);
            //update tb controller untuk tutup servo
            $this->scage_model->updateControl("1","0","Closed");
            echo $note;
        }  
    }

    function control($sensor,$status){  
        if($sensor == null || $status == null){
            echo "FIELD ANDA TIDAK ADA";
        } else{

            switch ($sensor) {
                case 'servo':
                    if($status==0){
                        $this->scage_model->updateControl("1","0","Closed");
                    } else {
                        $this->scage_model->updateControl("1","1","Open");
                    }
                break;
                
                case 'motor':
                    if($status==1){
                        $this->scage_model->updateControl("2","1","Go Left");
                    } else if($status==2) {
                        $this->scage_model->updateControl("2","2","Go Right");
                    } else {
                        $this->scage_model->updateControl("2","0","Stoped");
                    }
                break;

                case 'led':
                    if($status==0){
                        $this->scage_model->updateControl("3","0","OFF");
                    } else {
                        $this->scage_model->updateControl("3","1","ON");
                    }
                break;

                case 'restart':
                    $this->scage_model->updateControl("1","0","Closed");
                    $this->scage_model->updateControl("2","0","Stoped");
                    $this->scage_model->updateControl("3","0","OFF");
                break;

                default:
                    # code...
                    break;
            }
            redirect("home/smartcage"); 
        }
    }
}
?>