<?php

class Login extends CI_Controller {
   
    function __construct(){
        parent::__construct();

        $this->load->helper('url');
		$this->load->helper('form');
        $this->load->library('session');
        $this->load->model("user_model");
        $this->load->model("customer_model");
        $this->session_key = $this->config->item('session-key');
    }

    function index(){
        if($this->session->userdata("logcode") != $this->session_key){
            $this->load->view('page/login');
        } else {
            redirect("home");
        }
    }
    
    function user_login() {
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $logResult = $this->user_model->verifyLoginPassword($username,$password);

        switch($logResult) {
            case '1' :  //  Success  //
                        $this->setSession($username);
            break;
            case '2' :  // User Exist but Wrong Password //
                        $this->session->set_flashdata('message', "Password for $username is wrong, Check your Password");
            break;
            case '3' :  
                        $this->session->set_flashdata('message', "Username: $username not found");
            break;
        }
        redirect('login');
    }

    function setSession($username) {
        $this->user_model->login_out($username,"1");
        $data = $this->user_model->getByUsername($username);
        $profile = $this->customer_model->getByUsername($username);
        $sess_array = array(
            'logcode' => $this->session_key,
            'username' => "$data->username",
            'role' => "$data->id_role",
            'nama' => "$profile->nm_depan"." "."$profile->nm_belakang",
            'uid' => "$profile->uid_card",
            'url' => "$profile->url_profile"              
        );
        $this->session->set_userdata($sess_array);
    }

    function user_logout() { 
        $username = $this->session->userdata('username');
        $this->user_model->login_out($username,"0");
        $this->session->sess_destroy(); 
        redirect('login', 'refresh'); 
    }
}

?>