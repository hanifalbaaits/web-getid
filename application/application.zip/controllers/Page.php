<?php 

class Page extends CI_Controller{
    function __construct(){
        date_default_timezone_get('Asia/Jakarta');

        parent::__construct();
        $this->load->helper('url');
    }

    function not_found(){
        $this->load->view('page/404_notfound');
    }
}
?>