<?php 

class About extends CI_Controller{
    function __construct(){
        date_default_timezone_get('Asia/Jakarta');

        parent::__construct();
        $this->load->helper('url');
        $this->load->model("access_model");
        $this->session_key = $this->config->item('session-key');

        if($this->session->userdata('logcode') != $this->session_key){
            $this->session->set_flashdata('message', " Login Terlebih dahulu! ");
            redirect('login');
        }
    }

    function bogangdevelop(){      
        $menus['menus'] = $this->access_model->getByRole($this->session->userdata('role'));
        $this->load->view('frame/a_header');
        $this->load->view('frame/b_nav',$menus);
        $this->load->view('page/about_bogang');
        $this->load->view('frame/d_footer');      
    }
}
?>